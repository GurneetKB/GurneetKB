import os
import csv
from sqlite3 import IntegrityError
import sqlite3
import traceback
import jwt  # <<< ADDED
from flask import (
    Flask,
    request,
    jsonify,
    g,
)  # <<< MODIFIED: Removed session, render_template, etc. Added g

# from flask_session import Session # <<< REMOVED
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api, Resource
from flask_cors import CORS
from datetime import datetime, timedelta, timezone  # <<< ADDED timedelta, timezone
import hashlib
from functools import wraps  # <<< ADDED
from models import db, Professionals, Customer, ServiceRequest, Service, Users

import redis
from sqlalchemy import func
from datetime import timedelta
from datetime import datetime
from flask_mail import Mail
from flask_mail import Message

app = Flask(__name__)

# --- CORS Configuration (Allow Authorization header) ---
CORS(
    app,
    supports_credentials=False,  # We don't need credentials for cookies anymore
    origins=[
        "http://localhost:8080",
        "http://localhost:8081",
        "http://localhost:8082",
        "http://localhost:8083",
    ],
    allow_headers=["Content-Type", "Authorization"],
)  # <<< IMPORTANT: Allow Authorization Header

# --- Keep DB and Secret Key (Secret Key is now for JWT) ---
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(
    os.path.abspath(os.path.dirname(__file__)), "db.sqlite3"
)
app.config["SECRET_KEY"] = "abishek2002"  # Used to sign JWTs
app.config["CELERY_BROKER_URL"] = "redis://localhost:6379/1"
app.config["CELERY_RESULT_BACKEND"] = "redis://localhost:6379/2"
app.config["BROKER_CONNECTION_RETRY_ON_STARTUP"] = True
app.config["REDIS_HOST"] = "localhost"
app.config["REDIS_PORT"] = 6379
app.config["REDIS_DB"] = 0
db.init_app(app)
app.app_context().push()

db.create_all()


# Initialize Redis client
redis_client = redis.StrictRedis(host="localhost", port=6379, db=0)

from jobs import workers

celery = workers.celery
celery.Task = workers.ContextTask
app.app_context().push()

# Flask app configuration for MailHog
app.config["MAIL_SERVER"] = "localhost"
app.config["MAIL_PORT"] = 1025
app.config["MAIL_USE_TLS"] = False
app.config["MAIL_USE_SSL"] = False
app.config["MAIL_DEFAULT_SENDER"] = "21f1002028@ds.study.iitm.ac.in"
mail = Mail(app)
app.app_context().push()


@celery.task()
def send_daily_reminders():
    """Sends daily reminders to service professionals."""
    with app.app_context():  # Access Flask app context for database operations
        # Logic to fetch professionals with pending service requests.
        # Adapt this query to your specific database schema.
        pending_professionals = Professionals.query.filter_by(
            status="Pending"
        ).all()  # Example
        print(f"professionals: {pending_professionals}")
        for professional in pending_professionals:
            # Generate reminder message
            reminder_message = (
                f"Reminder: Professional {professional.prof_name} has pending service requests. "
                f"Please check your dashboard."
            )


# Password hashing (keep as is)
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(stored_password, provided_password):
    return stored_password == hashlib.sha256(provided_password.encode()).hexdigest()


# --- JWT Token Required Decorator ---
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        # Check for Bearer token in Authorization header
        if "Authorization" in request.headers:
            auth_header = request.headers["Authorization"]
            parts = auth_header.split()
            if len(parts) == 2 and parts[0].lower() == "bearer":
                token = parts[1]

        if not token:
            return jsonify({"message": "Token is missing!"}), 401

        try:
            # Decode and verify the token
            data = jwt.decode(token, app.config["SECRET_KEY"], algorithms=["HS256"])
            # Store decoded user data in Flask's global 'g' object for this request
            g.current_user = data
        except jwt.ExpiredSignatureError:
            return jsonify({"message": "Token has expired!"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"message": "Token is invalid!"}), 401
        except Exception as e:
            print(f"Token decoding error: {e}")
            traceback.print_exc()
            return jsonify({"message": "Token processing error"}), 500

        return f(*args, **kwargs)

    return decorated


# --- Routes ---


@app.route("/")
def home():
    return jsonify({"message": "Welcome to RuralBloom API (JWT Auth)"})


@app.route("/login", methods=["POST"])
def login():
    # Keep the initial checks and user fetching logic
    try:
        print("========= LOGIN ROUTE ENTERED (JWT) =========")
        data = request.get_json()
        if not data:
            return jsonify({"message": "No JSON data received"}), 400
        username = data.get("username")
        password = data.get("password")
        email = data.get("email")
        if not username or not password:
            return jsonify({"message": "Missing username or password or email"}), 400

        #  Special check for hardcoded admin and redirect ---
        if username == "Admin" and password == "admin":  # <<<<< BYPASS EVERYTHING ELSE
            print("Hardcoded Admin login successful!")
            token_payload = {
                "user_id": username,
                "user_type": "Admin",
                "exp": datetime.now(timezone.utc)
                + timedelta(hours=8),  # Token valid for 8 hours
            }
            token = jwt.encode(
                token_payload, app.config["SECRET_KEY"], algorithm="HS256"
            )
            print("Admin JWT Token generated successfully")
            # --- Return Token ---
            return (
                jsonify(
                    {
                        "message": f"Admin login successful",
                        "access_token": token,
                        "user_type": "Admin",
                        "user_id": username,  # Added user data
                        "redirect": "/admin/dashboard",  # For Frontend to take it from API and take redirect to admin
                    }
                ),
                200,
            )

        user = Users.query.filter_by(user_id=username).first()
        if not user:
            return jsonify({"message": "User not found"}), 404

        print(f"User_id: {user.user_id}")
        print(f"user_pwd: {user.user_pwd}")
        print(f"username: {username}")
        print(f"password: {password}")

        if verify_password(user.user_pwd, password):
            user_type = user.user_type
            print(f"Password verified for user: {username}, type: {user_type}")

            if user_type == "Customer":
                customer = Customer.query.filter_by(customer_id=username).first()
                if not customer or customer.status != "Unblocked":
                    return (
                        jsonify(
                            {
                                "message": "You cannot login due to user account being blocked. Please contact customer support"
                            }
                        ),
                        403,
                    )
            elif user_type == "Professional":
                professional = Professionals.query.filter_by(prof_id=username).first()
                if not professional or professional.status != "Verified":
                    return (
                        jsonify(
                            {
                                "message": "The professional account has been blocked or hasn't been verified yet."
                            }
                        ),
                        403,
                    )

            token_payload = {
                "user_id": username,
                "user_type": user_type,
                "exp": datetime.now(timezone.utc)
                + timedelta(hours=8),  # Token valid for 8 hours
            }
            token = jwt.encode(
                token_payload, app.config["SECRET_KEY"], algorithm="HS256"
            )
            print("JWT Token generated successfully")
            response = jsonify(
                {
                    "message": f"{user_type} login successful",
                    "access_token": token,
                    "user_type": user_type,  # Send user type back for frontend routing/UI
                    "user_id": username,  # Send user id back
                }
            )

            return response, 200
        else:
            print("ERROR: Invalid password")
            return jsonify({"message": "Invalid password"}), 401

    except Exception as e:
        print(f"========= EXCEPTION IN LOGIN (JWT): {e} =========")
        traceback.print_exc()
        return jsonify({"message": "Login failed due to server error"}), 500

    finally:
        print("========= LOGIN ROUTE EXITED (JWT) =========")


# --- Protect Routes with @token_required ---


# Example: Customer Dashboard
@app.route("/customer/dashboard")
@token_required  # <<< APPLY DECORATOR
def customer_dashboard():
    print("========= DASHBOARD ROUTE (JWT) =========")
    try:
        # Access user data from g object set by the decorator
        user_id = g.current_user["user_id"]
        user_type = g.current_user["user_type"]

        if user_type != "Customer":
            return jsonify({"message": "Access forbidden: Not a customer"}), 403

        # Fetch user data using user_id from token
        user = Customer.query.filter_by(customer_id=user_id).first()
        if user:
            services = Service.query.all()
            services_list = [
                {
                    "service_id": s.service_id,
                    "service_name": s.service_name,
                    "price": s.price,
                    "time_required": s.time_required,
                    "description": s.description,
                }
                for s in services
            ]
            user_data = {
                "customer_id": user.customer_id,
                "customer_name": user.customer_name,
                "customer_email": user.customer_email,
                "phone_no": user.phone_no,
                "address": user.address,
                "city": user.city,
                "status": user.status,
            }
            return jsonify({"user": user_data, "services": services_list}), 200
        else:
            return (
                jsonify({"message": "Customer data not found"}),
                404,
            )  # Should ideally not happen if token is valid

    except Exception as e:
        print(f"Error in customer_dashboard (JWT): {e}")
        traceback.print_exc()
        return jsonify({"message": "Error fetching customer dashboard"}), 500


# Example: Book Service
@app.route("/book_service/<service_id>", methods=["POST"])
@token_required  # <<< APPLY DECORATOR
def book_service(service_id):
    try:
        user_id = g.current_user["user_id"]
        user_type = g.current_user["user_type"]

        if user_type != "Customer":
            return jsonify({"message": "Only customers can book services"}), 403

        service = Service.query.get(service_id)
        if not service:
            return jsonify({"message": "Service not found"}), 404

        customer = Customer.query.get(user_id)  # Use user_id from token
        if not customer:
            return jsonify({"message": "Customer not found, please login"}), 404

        new_request = ServiceRequest(
            customer_id=user_id,  # Use user_id from token
            prof_id=" ",  # Or null depending on schema
            service_name=service.service_name,
            address=customer.address,
            city=customer.city,
            rating=0,
            status="Requested",  # Make sure status is set
        )
        db.session.add(new_request)
        db.session.commit()
        return jsonify({"message": "Service booked successfully"}), 200
    except Exception as e:
        db.session.rollback()
        print(f"Error in book_service (JWT): {e}")
        traceback.print_exc()
        return jsonify({"message": f"An error occurred while booking: {str(e)}"}), 500


@app.route("/customer/bookings")
@token_required
def get_customer_bookings():
    """
    Retrieves the booking history for a customer, given a valid JWT.
    """
    try:
        user_id = g.current_user["user_id"]
        user_type = g.current_user["user_type"]

        if user_type != "Customer":
            return jsonify({"message": "Access forbidden: Not a customer"}), 403

        # Query the ServiceRequest table for bookings associated with the customer
        bookings = ServiceRequest.query.filter_by(customer_id=user_id).all()

        # Serialize the booking data into a list of dictionaries
        booking_list = []
        for booking in bookings:
            booking_data = {
                "booking_id": booking.booking_id,
                "customer_id": booking.customer_id,
                "prof_id": booking.prof_id,
                "service_name": booking.service_name,
                "address": booking.address,
                "city": booking.city,
                "rating": booking.rating,
                "status": booking.status,
                # Format the timestamp to a readable string (optional)
                "order_date": (
                    booking.order_date.isoformat() if booking.order_date else None
                ),
            }
            booking_list.append(booking_data)

        # Return the list of bookings as a JSON response
        return jsonify({"bookings": booking_list}), 200

    except Exception as e:
        # Log the error and traceback for debugging
        print(f"Error in get_customer_bookings: {e}")
        traceback.print_exc()
        return jsonify({"message": f"Error retrieving bookings: {str(e)}"}), 500


# --- IMPORTANT ---
# Apply @token_required to ALL OTHER routes that need authentication:
# /customer/bookings
# /close_service/<int:booking_id>
# /service-professional/dashboard
# /accept_service_request/<int:booking_id>
# /admin/dashboard
# /service/add
# /service/edit
# /service/get_services
# /block_customer/<customer_id>
# /unblock_customer/<customer_id>
# etc...
#
# Also modify them to get the user_id/user_type from g.current_user
# instead of session, and perform necessary authorization checks
# (e.g., ensure only admin can call /block_customer).


# --- Registration routes remain largely the same (no token needed) ---
@app.route("/customer/register", methods=["POST", "OPTIONS"])
def customer_register():
    if request.method == "OPTIONS":
        # Respond to preflight request
        response = jsonify({"message": "CORS preflight request accepted"})
        response.headers.add(
            "Access-Control-Allow-Origin", "*"
        )  # Or your specific origin
        response.headers.add(
            "Access-Control-Allow-Headers", "Content-Type, Authorization"
        )  # Include Authorization
        response.headers.add(
            "Access-Control-Allow-Methods", "POST, OPTIONS"
        )  # Include OPTIONS
        return response, 200

    elif request.method == "POST":
        print("--- customer_register route STARTS (POST) ---")
        try:  # <---- ADD TRY BLOCK AROUND ENTIRE ROUTE LOGIC
            data = request.get_json()
            if not data:
                print("--- No JSON data received ---")
                return jsonify({"message": "No JSON data received"}), 400

            customer_id = data.get("username")
            customer_pwd = hash_password(data.get("password"))
            customer_email = data.get("email")
            customer_name = data.get("name")
            phone_no = data.get("phone")
            address = data.get("address")
            city = data.get("city")

            if not all(
                [
                    customer_id,
                    customer_pwd,
                    customer_email,
                    customer_name,
                    phone_no,
                    address,
                    city,
                ]
            ):
                print("--- Missing required fields ---")
                return jsonify({"message": "Missing required fields"}), 400

            customer = Customer(
                customer_id=customer_id,
                customer_pwd=customer_pwd,
                customer_email=customer_email,
                customer_name=customer_name,
                phone_no=phone_no,
                address=address,
                city=city,
            )
            user = Users(
                user_id=customer_id, user_pwd=customer_pwd, user_type="Customer"
            )
            print("--- Before db.session.add_all ---")
            db.session.add_all([customer, user])
            print("--- After db.session.add_all, before commit ---")
            db.session.commit()
            print("--- After db.session.commit - Registration SUCCESS ---")
            return jsonify({"message": "Customer registration successful"}), 201

        except IntegrityError as e:  # Catch IntegrityError (username exists)
            db.session.rollback()
            error_message = (
                "Username already exists. Please choose a different username."
            )
            print(f"--- IntegrityError: {error_message} ---")
            print(f"--- Exception details: {e} ---")
            traceback.print_exc()
            return (
                jsonify({"message": error_message}),
                409,
            )  # Return 409 Conflict for username exists

        except sqlite3.Error as e:  # Catch general sqlite3 database errors
            db.session.rollback()
            error_message = (
                "Database error during registration. Please try again later."
            )
            print(f"--- sqlite3.Error: {error_message} ---")
            print(f"--- Exception details: {e} ---")
            traceback.print_exc()
            return (
                jsonify({"message": error_message}),
                500,
            )  # Return 500 for database errors

        except Exception as e:  # Catch any other unexpected exceptions
            db.session.rollback()
            error_message = "Error during registration. Please try again."  # More generic error message
            print(f"--- General Exception during registration: {error_message} ---")
            print(f"--- Exception type: {type(e)} ---")
            print(f"--- Exception details: {e} ---")
            traceback.print_exc()
            return (
                jsonify({"message": error_message}),
                500,
            )  # Return 500 for unexpected errors

        finally:
            print("--- customer_register route ENDS (POST) ---")

    else:
        return jsonify({"message": "Method not allowed"}), 405


@app.route("/service/get_services")
def get_services():
    try:
        services = Service.query.all()
        services_list = []
        for service in services:
            services_list.append(
                {
                    "service_id": service.service_id,
                    "service_name": service.service_name,
                    "price": service.price,
                    "time_required": service.time_required,
                    "description": service.description,
                }
            )
        return jsonify({"services": services_list}), 200
    except Exception as e:
        print(f"Error in get_services: {e}")
        traceback.print_exc()
        return jsonify({"message": "Error fetching services"}), 500


# Close Service
@app.route("/close_booking/<int:booking_id>", methods=["POST"])
@token_required
def close_booking(booking_id):
    """
    Closes a booking, updating its status and rating. Requires a valid JWT.
    """
    try:
        user_id = g.current_user["user_id"]
        user_type = g.current_user["user_type"]

        if user_type != "Customer":
            return (
                jsonify(
                    {"message": "Access forbidden: Only customers can close bookings"}
                ),
                403,
            )

        # 1. Retrieve the booking from the database
        booking = ServiceRequest.query.get(
            booking_id
        )  # Assuming ServiceRequest is the model
        if not booking:
            return jsonify({"message": "Booking not found"}), 404

        # 2. Check if the booking is already closed
        if booking.status == "Closed":
            return jsonify({"message": "Booking is already closed"}), 400

        # 3. Get the rating from the request body
        data = request.get_json()
        rating = data.get("rating")

        # 4. Validate the rating
        if not isinstance(rating, (int, float)):
            return jsonify({"message": "Invalid rating value"}), 400
        if not 1 <= rating <= 5:
            return jsonify({"message": "Rating must be between 1 and 5"}), 400

        # 5. Update the booking status and rating
        booking.status = "Closed"
        booking.rating = rating
        db.session.commit()

        # 6. Return a success message
        return jsonify({"message": "Booking closed successfully"}), 200

    except Exception as e:
        db.session.rollback()  # Rollback on error
        print(f"Error in close_booking: {e}")
        traceback.print_exc()
        return jsonify({"message": f"Error closing booking: {str(e)}"}), 500


# Register Service Professional
@app.route("/service-professional/register", methods=["POST"])
def service_professional_register():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"message": "No JSON data received"}), 400

        prof_id = data.get("username")
        prof_pwd = hash_password(data.get("password"))
        prof_email = data.get("email")
        prof_name = data.get("name")
        phone = data.get("phone")
        serv_type = data.get("service_type")
        experience = int(data.get("experience"))

        if not all(
            [prof_id, prof_pwd, prof_email, prof_name, phone, serv_type, experience]
        ):
            return jsonify({"message": "Missing required fields"}), 400

        professional = Professionals(
            prof_id=prof_id,
            prof_pwd=prof_pwd,
            prof_email=prof_email,
            prof_name=prof_name,
            phone=phone,
            join_date=datetime.utcnow(),
            serv_type=serv_type,
            experience=experience,
            prof_rating=0,
        )
        user = Users(  # Add entry to Users table
            user_id=prof_id, user_pwd=prof_pwd, user_type="Professional"
        )
        db.session.add_all([professional, user])  # Add both professional and user
        db.session.commit()
        return jsonify({"message": "Service Professional Registration successful"}), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify({"message": "Username already exists"}), 409
    except Exception as e:
        db.session.rollback()
        print(f"Error in service_professional_register: {e}")
        traceback.print_exc()
        return jsonify({"message": f"Registration failed: {str(e)}"}), 500


@app.route("/service-professional/dashboard")
@token_required
def service_professional_dashboard():
    """
    Retrieves the dashboard data for a service professional, including their
    profile information and a list of service requests.  Requires a valid JWT.
    """
    try:
        user_id = g.current_user["user_id"]
        user_type = g.current_user["user_type"]

        if user_type != "Professional":
            return (
                jsonify({"message": "Access forbidden: Not a service professional"}),
                403,
            )

        # 1. Fetch the service professional's profile information
        professional = Professionals.query.filter_by(
            prof_id=user_id
        ).first()  # Using prof_id
        if not professional:
            return jsonify({"message": "Service professional not found"}), 404

        # 2. Fetch the service requests associated with the professional (adjust the query as needed)
        service_requests = ServiceRequest.query.filter(
            ServiceRequest.service_name == professional.serv_type,
            ServiceRequest.status == "Requested",
        ).all()

        # 3. Serialize the data to JSON (very important)
        professional_data = {
            "prof_id": professional.prof_id,
            "prof_name": professional.prof_name,
            "prof_email": professional.prof_email,
            "phone": professional.phone,
            "join_date": (
                professional.join_date.isoformat() if professional.join_date else None
            ),
            "serv_type": professional.serv_type,
            "experience": professional.experience,
            "prof_rating": professional.prof_rating,
        }

        service_requests_list = []
        for request in service_requests:
            request_data = {
                "booking_id": request.booking_id,
                "customer_id": request.customer_id,
                "prof_id": request.prof_id,  # Or None if null in DB
                "service_name": request.service_name,
                "address": request.address,
                "city": request.city,
                "rating": request.rating,
                "status": request.status,
                "order_date": (
                    request.order_date.isoformat() if request.order_date else None
                ),
            }
            service_requests_list.append(request_data)

        # 4. Return the data as JSON
        return (
            jsonify(
                {
                    "professional": professional_data,
                    "service_requests": service_requests_list,
                }
            ),
            200,
        )

    except Exception as e:
        # Log the error and traceback
        print(f"Error in service_professional_dashboard: {e}")
        traceback.print_exc()
        return (
            jsonify(
                {"message": f"Error fetching service professional dashboard: {str(e)}"}
            ),
            500,
        )


# Service Accepting by Service Prof
@app.route("/accept_service_request/<int:booking_id>", methods=["POST"])
@token_required
def accept_service_request(booking_id):
    """
    Accepts a service request, updating its status and assigning it to the professional.
    Requires a valid JWT.
    """
    try:
        user_id = g.current_user["user_id"]
        user_type = g.current_user["user_type"]

        if user_type != "Professional":
            return (
                jsonify(
                    {
                        "message": "Access forbidden: Only professionals can accept service requests"
                    }
                ),
                403,
            )

        # 1. Retrieve the service request from the database
        service_request = ServiceRequest.query.get(booking_id)
        if not service_request:
            return jsonify({"message": "Service request not found"}), 404

        # 2. Check if the service request is already accepted or completed
        if (
            service_request.status != "Requested"
        ):  # Assuming initial status is "Requested"
            return (
                jsonify(
                    {"message": "Service request is already accepted or completed"}
                ),
                400,
            )

        # 3. Update the service request status and assign it to the professional
        service_request.status = "Accepted"
        service_request.prof_id = user_id  # Assign to the accepting professional
        db.session.commit()

        # 4. Return a success message
        return jsonify({"message": "Service request accepted successfully"}), 200

    except Exception as e:
        db.session.rollback()  # Rollback on error
        print(f"Error in accept_service_request: {e}")
        traceback.print_exc()
        return jsonify({"message": f"Error accepting service request: {str(e)}"}), 500


@app.route("/admin/customers")
@token_required
def view_all_customers_api():  # Renamed slightly to avoid conflict if old one exists
    """
    API endpoint for admins to view all customers. Requires valid Admin JWT.
    """
    try:
        # Authorization check using token data
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        customers = Customer.query.all()
        customers_list = []
        for cust in customers:
            customers_list.append(
                {
                    "customer_id": cust.customer_id,
                    "customer_name": cust.customer_name,
                    "customer_email": cust.customer_email,
                    "phone_no": cust.phone_no,
                    "address": cust.address,  # Added address if needed by frontend
                    "city": cust.city,
                    "status": cust.status,
                }
            )
        # IMPORTANT: Return JSON with the key 'customers' that the frontend expects
        return jsonify({"customers": customers_list}), 200
    except Exception as e:
        print(f"Error in view_all_customers_api: {e}")
        traceback.print_exc()
        return jsonify({"message": "Error fetching customers"}), 500


@app.route("/admin/professionals")
@token_required
def view_all_professionals_api():  # Renamed slightly
    """
    API endpoint for admins to view all professionals. Requires valid Admin JWT.
    """
    try:
        # Authorization check using token data
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        professionals = Professionals.query.all()
        professionals_list = []
        for prof in professionals:
            professionals_list.append(
                {
                    "prof_id": prof.prof_id,
                    "prof_name": prof.prof_name,
                    "prof_email": prof.prof_email,
                    "phone": prof.phone,  # Added phone if needed
                    "serv_type": prof.serv_type,
                    "experience": prof.experience,
                    "prof_rating": prof.prof_rating,
                    "status": prof.status,
                    # Add other fields if needed by frontend
                }
            )
        # IMPORTANT: Return JSON with the key 'professionals' that the frontend expects
        return jsonify({"professionals": professionals_list}), 200
    except Exception as e:
        print(f"Error in view_all_professionals_api: {e}")
        traceback.print_exc()
        return jsonify({"message": "Error fetching professionals"}), 500


# --- Ensure other required admin routes like /accept_professional also exist ---
@app.route("/accept_professional/<professional_id>", methods=["POST"])
@token_required
def accept_professional_api(professional_id):  # Added API suffix for clarity
    try:
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        professional = Professionals.query.get_or_404(professional_id)
        professional.status = "Verified"  # Or appropriate status
        db.session.commit()
        return jsonify({"message": "Professional accepted/verified successfully"}), 200
    except Exception as e:
        db.session.rollback()
        print(f"Error in accept_professional_api: {e}")
        traceback.print_exc()
        return jsonify({"message": "Error accepting professional"}), 500


# --- Make sure the block/unblock routes from before also exist and use @token_required ---
# @app.route('/block_customer/<customer_id>', methods=['POST']) @token_required ...
# @app.route('/unblock_customer/<customer_id>', methods=['POST']) @token_required ...
# @app.route('/block_professional/<professional_id>', methods=['POST']) @token_required ...
# @app.route('/unblock_professional/<professional_id>', methods=['POST']) @token_required ...


# Example modification for an admin route:
@app.route("/block_customer/<customer_id>", methods=["POST"])
@token_required
def block_customer(customer_id):
    try:
        # Authorization check using token data
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        customer = Customer.query.get_or_404(customer_id)
        customer.status = "Blocked"
        db.session.commit()
        return jsonify({"message": "Customer blocked successfully"}), 200
    except Exception as e:
        db.session.rollback()
        print(f"Error in block_customer (JWT): {e}")
        traceback.print_exc()
        return jsonify({"message": f"Error blocking customer: {str(e)}"}), 500


@app.route("/unblock_customer/<customer_id>", methods=["POST"])
@token_required
def unblock_customer_api(customer_id):
    """
    API endpoint for admins to unblock a customer. Requires valid Admin JWT.
    """
    try:
        # 1. Authorization Check
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        # 2. Find Customer or return 404
        customer = Customer.query.get_or_404(customer_id)

        # 3. Update Status
        customer.status = "Unblocked"
        db.session.commit()

        print(
            f"Customer '{customer_id}' unblocked successfully by admin '{g.current_user['user_id']}'"
        )
        return jsonify({"message": "Customer unblocked successfully"}), 200

    except Exception as e:
        db.session.rollback()  # Rollback in case of error during commit
        print(f"Error in unblock_customer_api for ID {customer_id}: {e}")
        traceback.print_exc()
        # Check if it was a 404 from get_or_404 before the exception handler caught it
        if hasattr(e, "code") and e.code == 404:
            return (
                jsonify({"message": f"Customer with ID {customer_id} not found"}),
                404,
            )
        return jsonify({"message": f"Error unblocking customer: {str(e)}"}), 500


# --- Block Professional Route ---
@app.route("/block_professional/<professional_id>", methods=["POST"])
@token_required
def block_professional_api(professional_id):
    """
    API endpoint for admins to block a professional. Requires valid Admin JWT.
    """
    try:
        # 1. Authorization Check
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        # 2. Find Professional or return 404
        # Note: The model uses prof_id, but the route uses professional_id
        professional = Professionals.query.get_or_404(professional_id)

        # 3. Update Status
        professional.status = "Blocked"
        db.session.commit()

        print(
            f"Professional '{professional_id}' blocked successfully by admin '{g.current_user['user_id']}'"
        )
        return jsonify({"message": "Professional blocked successfully"}), 200

    except Exception as e:
        db.session.rollback()
        print(f"Error in block_professional_api for ID {professional_id}: {e}")
        traceback.print_exc()
        if hasattr(e, "code") and e.code == 404:
            return (
                jsonify(
                    {"message": f"Professional with ID {professional_id} not found"}
                ),
                404,
            )
        return jsonify({"message": f"Error blocking professional: {str(e)}"}), 500


# --- Unblock Professional Route ---
@app.route("/unblock_professional/<professional_id>", methods=["POST"])
@token_required
def unblock_professional_api(professional_id):
    """
    API endpoint for admins to unblock (verify) a professional. Requires valid Admin JWT.
    """
    try:
        # 1. Authorization Check
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        # 2. Find Professional or return 404
        professional = Professionals.query.get_or_404(professional_id)

        # 3. Update Status (Setting to 'Verified' acts as unblock)
        professional.status = "Verified"
        db.session.commit()

        print(
            f"Professional '{professional_id}' unblocked/verified successfully by admin '{g.current_user['user_id']}'"
        )
        return jsonify({"message": "Professional unblocked/verified successfully"}), 200

    except Exception as e:
        db.session.rollback()
        print(f"Error in unblock_professional_api for ID {professional_id}: {e}")
        traceback.print_exc()
        if hasattr(e, "code") and e.code == 404:
            return (
                jsonify(
                    {"message": f"Professional with ID {professional_id} not found"}
                ),
                404,
            )
        return jsonify({"message": f"Error unblocking professional: {str(e)}"}), 500


# Post Request and Ensure Admin
@app.route("/service/add", methods=["POST"])
@token_required
def add_service():
    try:
        # Verify user type - ensure that you check "ADMIN" user or it wont function with the login
        if g.current_user["user_type"] != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        data = request.get_json()
        if not data:
            return jsonify({"message": "No JSON data received"}), 400

        service_id = data.get("service_id")
        service_name = data.get("service_name")
        price = data.get("price")
        time_required = data.get("time_required")
        description = data.get("description")

        if not all([service_id, service_name, price, time_required, description]):
            return jsonify({"message": "Missing required fields"}), 400

        new_service = Service(
            service_id=service_id,
            service_name=service_name,
            price=price,
            time_required=time_required,
            description=description,
        )
        db.session.add(new_service)
        db.session.commit()
        return jsonify({"message": "Service added successfully"}), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify({"message": "Service ID already exists"}), 409
    except Exception as e:
        db.session.rollback()
        print(f"Error in add_service: {e}")
        traceback.print_exc()
        return jsonify({"message": f"Error adding service: {str(e)}"}), 500


# Post Request and Ensure Admin
@app.route("/service/edit", methods=["POST"])
@token_required
def edit_service():
    try:
        # Verify user type
        admin_type = g.current_user["user_type"]
        if admin_type != "Admin":
            return jsonify({"message": "Admin access required"}), 403

        data = request.get_json()  # Get data from the request body
        if not data:
            return jsonify({"message": "No JSON data received"}), 400

        service_id = data.get("service_id")
        service_name = data.get("service_name")
        price = data.get("price")
        time_required = data.get("time_required")
        description = data.get("description")

        if not all([service_id, service_name, price, time_required, description]):
            return jsonify({"message": "Missing required fields"}), 400

        service = Service.query.filter_by(service_id=service_id).first()
        if not service:
            return jsonify({"message": "Service not found"}), 404

        # Update the service with new data
        service.service_name = service_name
        service.price = price
        service.time_required = time_required
        service.description = description

        db.session.commit()
        return jsonify({"message": "Service updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        print(f"Error in edit_service: {e}")
        traceback.print_exc()
        return jsonify({"message": f"Error editing service: {str(e)}"}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)  # Default Flask port is 5000
