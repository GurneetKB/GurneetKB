from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


# Users table model
class Users(db.Model):
    __tablename__ = "Users"
    user_id = db.Column(db.String(100), primary_key=True, unique=True)
    user_pwd = db.Column(db.String(100), nullable=False)
    user_type = db.Column(db.String(10), default="Customer")


# Professionals table model
class Professionals(db.Model):
    __tablename__ = "professionals"
    prof_id = db.Column(db.String(100), primary_key=True, unique=True)
    prof_pwd = db.Column(db.String(100), nullable=False)
    prof_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.Integer, nullable=False)
    join_date = db.Column(db.DateTime, default=datetime.utcnow)
    serv_type = db.Column(db.String(100), nullable=False)
    experience = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default="Pending")
    prof_rating = db.Column(db.Integer, default=0)
    prof_email = db.Column(db.String(100), nullable=False)


# Customer/User table model
class Customer(db.Model):
    __tablename__ = "customer"
    customer_id = db.Column(db.String(100), primary_key=True, unique=True)
    customer_pwd = db.Column(db.String(100), nullable=False)
    customer_name = db.Column(db.String(100), nullable=False)
    phone_no = db.Column(db.String(15), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default="Unblocked")
    customer_email = db.Column(db.String(100), nullable=False)


# Booking/Service Request table model
class ServiceRequest(db.Model):
    __tablename__ = "service_request"
    booking_id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(
        db.String(100), db.ForeignKey("customer.customer_id"), nullable=False
    )
    prof_id = db.Column(
        db.String(100), db.ForeignKey("professionals.prof_id"), nullable=False
    )
    service_name = db.Column(
        db.String(100), db.ForeignKey("service.service_name"), nullable=False
    )
    order_date = db.Column(db.DateTime, default=datetime.utcnow)
    address = db.Column(db.String(200))
    city = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default="Requested")
    rating = db.Column(db.Integer, nullable=False)

    service = db.relationship("Service")


# Service type table model
class Service(db.Model):
    __tablename__ = "service"
    service_id = db.Column(db.String(100), primary_key=True, unique=True)
    service_name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Integer, nullable=False)
    time_required = db.Column(db.Integer)
    description = db.Column(db.String(200))
