from app import app, db, Service, Users, Customer, Professionals

services_list = [
    # Services for "Home Cleaning" category
    {'service_id': 'HC01', 'service_name': 'Basic Room Cleaning', 'price': 200, 'time_required': 30, 'description': 'Cleaning of room surfaces and floors'},
    {'service_id': 'HC02', 'service_name': 'Deep Kitchen Cleaning', 'price': 500, 'time_required': 60, 'description': 'Intensive cleaning of kitchen areas'},
    {'service_id': 'HC03', 'service_name': 'Window Cleaning', 'price': 150, 'time_required': 20, 'description': 'Glass and window cleaning'},
    {'service_id': 'HC04', 'service_name': 'Bathroom Cleaning', 'price': 300, 'time_required': 40, 'description': 'Cleaning of bathroom surfaces and floors'},

    # Services for "Plumbing" category
    {'service_id': 'PL01', 'service_name': 'Leak Repair', 'price': 250, 'time_required': 45, 'description': 'Fixing water leaks'},
    {'service_id': 'PL02', 'service_name': 'Pipe Installation', 'price': 600, 'time_required': 90, 'description': 'Installation of pipes'},
    {'service_id': 'PL03', 'service_name': 'Drain Unclogging', 'price': 300, 'time_required': 50, 'description': 'Unclogging drains'},
    {'service_id': 'PL04', 'service_name': 'Water Heater Installation', 'price': 700, 'time_required': 120, 'description': 'Installation of water heaters'},

    # Services for "Electrical" category
    {'service_id': 'EL01', 'service_name': 'Fan Repair', 'price': 150, 'time_required': 30, 'description': 'Repairing ceiling or table fans'},
    {'service_id': 'EL02', 'service_name': 'Switch Replacement', 'price': 100, 'time_required': 15, 'description': 'Replacing electrical switches'},
    {'service_id': 'EL03', 'service_name': 'Wiring Check', 'price': 400, 'time_required': 60, 'description': 'Checking home wiring'},
    {'service_id': 'EL04', 'service_name': 'Light Installation', 'price': 200, 'time_required': 30, 'description': 'Installing light fixtures'},

    # Services for "Beauty and Wellness" category
    {'service_id': 'BW01', 'service_name': 'Facial Treatment', 'price': 500, 'time_required': 60, 'description': 'Basic facial treatment'},
    {'service_id': 'BW02', 'service_name': 'Manicure', 'price': 300, 'time_required': 45, 'description': 'Basic manicure service'},
    {'service_id': 'BW03', 'service_name': 'Haircut', 'price': 400, 'time_required': 50, 'description': 'Basic haircut'},
    {'service_id': 'BW04', 'service_name': 'Massage', 'price': 600, 'time_required': 90, 'description': 'Full body massage'},

    # Services for "Appliance Repair" category
    {'service_id': 'AR01', 'service_name': 'Refrigerator Repair', 'price': 800, 'time_required': 120, 'description': 'Repairing refrigerator issues'},
    {'service_id': 'AR02', 'service_name': 'Washing Machine Repair', 'price': 700, 'time_required': 90, 'description': 'Repairing washing machines'},
    {'service_id': 'AR03', 'service_name': 'Microwave Repair', 'price': 500, 'time_required': 60, 'description': 'Fixing microwave issues'},
    {'service_id': 'AR04', 'service_name': 'Air Conditioner Repair', 'price': 1000, 'time_required': 150, 'description': 'Repairing air conditioners'},

    # Services for "Carpentry" category
    {'service_id': 'CR01', 'service_name': 'Furniture Assembly', 'price': 250, 'time_required': 60, 'description': 'Assembly of furniture pieces'},
    {'service_id': 'CR02', 'service_name': 'Door Repair', 'price': 200, 'time_required': 45, 'description': 'Repairing doors'},
    {'service_id': 'CR03', 'service_name': 'Window Frame Fixing', 'price': 300, 'time_required': 70, 'description': 'Fixing window frames'},
    {'service_id': 'CR04', 'service_name': 'Shelf Installation', 'price': 400, 'time_required': 80, 'description': 'Installing wall shelves'},
]


user_list = [
    {'user_id': 'Admin', 'user_pwd': 'admin', 'user_type': 'Admin'}
]


with app.app_context():
    # Clear existing data
    db.session.query(Service).delete()
    db.session.query(Users).delete()
    db.session.query(Professionals).delete()    
    db.session.query(Customer).delete()
    db.session.commit()

    # Insert services
    for service_data in services_list:
        service = Service(
            service_id=service_data['service_id'],
            service_name=service_data['service_name'],
            price=service_data['price'],
            time_required=service_data['time_required'],
            description=service_data['description'],
        )
        db.session.add(service)

    # Insert user(s)
    for user_data in user_list:
        user = Users(
            user_id=user_data['user_id'],
            user_pwd=user_data['user_pwd'],
            user_type=user_data['user_type']
        )
        db.session.add(user)

    db.session.commit()
    print("✅ Database seeded successfully!")
