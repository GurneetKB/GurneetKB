from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/customer/register', methods=['POST', 'OPTIONS'])
def customer_register():
    if request.method == 'OPTIONS':
        response = jsonify({"message": "CORS preflight request accepted"})
        response.headers.add('Access-Control-Allow-Origin', 'http://localhost:8081')  #  <--- YOUR VUE APP'S ORIGIN
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST')
        return response, 200

    # ... your registration logic ...

if __name__ == '__main__':
    app.run(debug=True)