<template>
  <div>
    <Navbar />  <!-- Navbar is always rendered -->
    <router-view />
  </div>
</template>

<script>
import Navbar from './components/NavBar.vue';

export default {
  name: 'App',
  components: {
    Navbar,
  },
  // Computed property and v-if are REMOVED
  // No need for isAppPage in this scenario
};
</script>

<style scoped>
</style>
