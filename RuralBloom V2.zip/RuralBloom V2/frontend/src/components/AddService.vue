<template>
  <div class="form-container">
    <h1>Add a New Service</h1>
    <div v-if="isLoading" class="loading-indicator">Adding service...</div>
    <div v-if="error" class="error-text">Error: {{ error }}</div>

    <form @submit.prevent="submitForm" v-if="!isLoading">
      <div class="form-group">
        <label for="service_id">Service ID:</label>
        <input type="text" id="service_id" v-model="service.service_id" required>
      </div>

      <div class="form-group">
        <label for="service_name">Service Name:</label>
        <input type="text" id="service_name" v-model="service.service_name" required>
      </div>

      <div class="form-group">
        <label for="price">Price:</label>
        <input type="number" id="price" v-model.number="service.price" required min="0">
      </div>

      <div class="form-group">
        <label for="time_required">Time Required (mins):</label>
        <input type="number" id="time_required" v-model.number="service.time_required" min="0">
      </div>

      <div class="form-group">
        <label for="description">Description:</label>
        <textarea id="description" v-model="service.description" rows="5" required></textarea>
      </div>

      <button type="submit" class="btn">Add Service</button>
       <router-link to="/admin/dashboard" class="btn cancel-btn">Cancel</router-link> <!-- Added Cancel -->
    </form>
  </div>
</template>

<script>
// --- IMPORT apiClient ---
import apiClient from '../apiClient'; // Adjust path if needed

export default {
  name: 'AddService', // Add name
  data() {
    return {
      service: {
        service_id: '',
        service_name: '',
        price: null,
        time_required: null,
        description: ''
      },
      isLoading: false,
      error: null,
    };
  },
  methods: {
    async submitForm() {
      this.isLoading = true;
      this.error = null;
      console.log("Attempting to add service:", this.service);
      try {
        // --- USE apiClient ---
        // Ensure backend route '/service/add' exists, uses POST, and is protected
        const response = await apiClient.post('/service/add', this.service);

        // Backend returns 201 Created on success typically
        if (response.status === 201) {
          console.log('Service added successfully:', response.data);
          alert(response.data?.message || 'Service added successfully!');
          this.resetForm();
          this.$router.push('/admin/dashboard'); // Optional: redirect after success
        } else {
          // Handle other potential success codes if needed, or treat as error
          console.warn('Add service responded with status:', response.status, response.data);
          this.error = response.data?.message || `Failed to add service (Status: ${response.status})`;
        }

      } catch (error) {
        console.error('Error adding service:', error);
        if (error.response && error.response.status !== 401) {
            // Handle specific errors like 409 Conflict (Service ID exists)
            this.error = `Error adding service (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
        } else if (!error.response) {
            this.error = 'Could not connect to the server.';
        } else {
            this.error = 'Authentication error.'; // 401 handled by interceptor
        }
      } finally {
          this.isLoading = false;
      }
    },
    resetForm() {
      this.service = {
        service_id: '',
        service_name: '',
        price: null,
        time_required: null,
        description: ''
      };
    }
  }
};
</script>

<style scoped>
.form-container {
  max-width: 600px;
  margin: 20px auto;
  padding: 20px;
  background-color: #2a2a2a; /* Match other dark themes */
  border: 1px solid #007bff;
  border-radius: 8px;
  color: #e0e0e0;
}

h1 {
  text-align: center;
  color: #00aaff;
  margin-bottom: 25px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

input[type="text"],
input[type="number"],
textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #555;
  border-radius: 4px;
  background-color: #333;
  color: #fff;
  box-sizing: border-box;
}
input:focus, textarea:focus {
    border-color: #00aaff;
    outline: none;
}

textarea {
  resize: vertical; /* Allow vertical resize */
}

.btn {
  display: inline-block;
  padding: 10px 20px;
  margin-right: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  text-decoration: none;
  text-align: center;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s ease;
}
.btn:hover {
  background-color: #0056b3;
}
.cancel-btn {
    background-color: #6c757d;
}
.cancel-btn:hover {
    background-color: #5a6268;
}

.loading-indicator, .error-text {
    text-align: center;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 4px;
}
.loading-indicator { color: #00aaff; }
.error-text { color: #ff4d4d; background-color: rgba(255, 77, 77, 0.1); border: 1px solid #ff4d4d;}
</style>