<template>
    <div>
        <!-- Hero Section -->
        <div class="hero">
            <h1>Welcome to RuralBoom Household Services</h1>
            <p>Professional services right at your doorstep. Book quality service providers quickly and easily.</p>
            <router-link to="/login" class="btn">Get Started</router-link>  <!-- Corrected route for Get Started button -->
        </div>

        <!-- Footer -->
        <footer>
            <p> 2024 RuralBoom Services. All rights reserved.</p>
        </footer>
    </div>
</template>

<style scoped>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .navbar {
        text-align: right;
        background-color: #000000;
        color: white;
        padding: 10px;
    }
    .navbar a {
        text-align: right;
        color: white;
        text-decoration: none;
        margin-right: 15px;
    }
    .navbar a:hover {
        text-decoration: underline;
    }
    .hero {
        background-color: #f8f9fa;
        text-align: center;
        padding: 50px 20px;
    }
    .hero h1 {
        font-size: 2.5em;
        margin: 0 0 10px;
    }
    .hero p {
        margin: 0 0 20px;
    }
    .hero .btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #007bff;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }
    .hero .btn:hover {
        background-color: #0056b3;
    }
    footer {
        background-color: #000000;
        color: white;
        text-align: center;
        padding: 10px 0;
        margin-top: 20px;
    }
</style>

<script>
export default {
    name: "HomePage"
};
</script>