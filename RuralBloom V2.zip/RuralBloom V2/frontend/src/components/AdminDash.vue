<template>
    <div class="dashboard">
        <!-- Navbar -->
        <div class="navbar">
            <router-link to="/" class="nav-link">Home</router-link>
            <!-- Add Admin Logout -->
            <button @click="logout" class="logout-nav-btn">Admin Logout</button>
        </div>
  
        <!-- Banner -->
        <div class="banner">
            <h1>Admin Dashboard</h1>
        </div>
  
        <div class="container">
            <!-- Loading / Error Display -->
            <div v-if="loading" class="loading-indicator">Loading Dashboard Data...</div>
            <div v-if="error" class="error-text">Error: {{ error }}</div>
  
            <div v-if="!loading && !error">
                <!-- Search Customers -->
                <div class="section-title">Search Customers</div>
                <input type="text" class="search-bar" v-model="customerSearch" placeholder="Search by name, city, etc." />
  
                <!-- Customers Table -->
                <div class="section-title">All Customers ({{ filteredCustomers.length }})</div>
                <table v-if="filteredCustomers.length > 0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone No</th>
                            <th>City</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="customer in filteredCustomers" :key="customer.customer_id">
                            <td>{{ customer.customer_id }}</td>
                            <td>{{ customer.customer_name }}</td>
                            <td>{{ customer.phone_no }}</td>
                            <td>{{ customer.city }}</td>
                            <td>{{ customer.status }}</td>
                            <td>
                                <!-- Prevent multiple clicks while action is processing -->
                                <button v-if="customer.status !== 'Blocked'"
                                        @click="blockCustomer(customer.customer_id)"
                                        :disabled="isActionProcessing === customer.customer_id"
                                        class="btn btn-block">
                                    {{ isActionProcessing === customer.customer_id ? 'Blocking...' : 'Block' }}
                                </button>
                                <button v-if="customer.status === 'Blocked'"
                                        @click="unblockCustomer(customer.customer_id)"
                                        :disabled="isActionProcessing === customer.customer_id"
                                        class="btn btn-unblock">
                                    {{ isActionProcessing === customer.customer_id ? 'Unblocking...' : 'Unblock' }}
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p v-else-if="customerSearch && filteredCustomers.length === 0" class="no-results">No customers match your search.</p>
                <p v-else class="no-results">No customers found.</p>
  
  
                <!-- Search Professionals -->
                <div class="section-title">Search Professionals</div>
                <input type="text" class="search-bar" v-model="professionalSearch" placeholder="Search by name, service type, etc." />
  
                <!-- Professionals Table -->
                <div class="section-title">All Professionals ({{ filteredProfessionals.length }})</div>
                <table v-if="filteredProfessionals.length > 0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Service Type</th>
                            <th>Experience</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="professional in filteredProfessionals" :key="professional.prof_id">
                            <td>{{ professional.prof_id }}</td>
                            <td>{{ professional.prof_name }}</td>
                            <td>{{ professional.serv_type }}</td>
                            <td>{{ professional.experience }}</td>
                            <td>{{ professional.status }}</td>
                            <td>
                                <button v-if="professional.status !== 'Blocked' && professional.status !== 'Pending'"
                                        @click="blockProfessional(professional.prof_id)"
                                        :disabled="isActionProcessing === professional.prof_id"
                                        class="btn btn-block">
                                     {{ isActionProcessing === professional.prof_id ? 'Blocking...' : 'Block' }}
                                </button>
                                <button v-if="professional.status === 'Blocked'"
                                        @click="unblockProfessional(professional.prof_id)"
                                         :disabled="isActionProcessing === professional.prof_id"
                                        class="btn btn-unblock">
                                     {{ isActionProcessing === professional.prof_id ? 'Unblocking...' : 'Unblock' }}
                                </button>
                                 <!-- Assuming 'Pending' is a status for newly registered professionals -->
                                <button v-if="professional.status === 'Pending'"
                                        @click="acceptProfessional(professional.prof_id)"
                                        :disabled="isActionProcessing === professional.prof_id"
                                        class="btn btn-accept">
                                     {{ isActionProcessing === professional.prof_id ? 'Accepting...' : 'Accept' }}
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                 <p v-else-if="professionalSearch && filteredProfessionals.length === 0" class="no-results">No professionals match your search.</p>
                <p v-else class="no-results">No professionals found.</p>
  
                <!-- Display action error if any -->
                 <div v-if="actionError" class="error-text small-error">
                      {{ actionError }}
                 </div>
  
  
                <!-- Service Management Buttons -->
                <div class="service-management">
                    <router-link to="/service/add" class="btn btn-service">Add a Service</router-link>
                    <router-link to="/service/edit" class="btn btn-service">Edit a Service</router-link>
                </div>
  
  
                <!-- Trigger Detailed Report Button (Still commented out) -->
                <!--
                <div class="report-section">
                    <button class="btn" @click="triggerReport">Trigger Detailed Report</button>
                    <p v-if="reportStatus" class="report-status">{{ reportStatus }}</p>
                </div>
                -->
            </div>
        </div>
    </div>
  </template>
  
  <script>
  // --- IMPORT apiClient ---
  import apiClient from '../apiClient'; // Adjust path if needed
  
  export default {
    name: 'AdminDash', // Add name
    data() {
        return {
            customers: [],
            professionals: [],
            customerSearch: "",
            professionalSearch: "",
            reportStatus: "", // Keep if using report feature later
            loading: true, // Start in loading state
            error: null, // For general fetch errors
            isActionProcessing: null, // Track which user ID is being processed
            actionError: null, // Specific error for actions like block/unblock
        };
    },
    computed: {
        filteredCustomers() {
            if (!this.customerSearch) return this.customers;
            const search = this.customerSearch.toLowerCase();
            return this.customers.filter((customer) =>
                (customer.customer_name?.toLowerCase() || '').includes(search) ||
                (customer.city?.toLowerCase() || '').includes(search) ||
                (customer.customer_id?.toLowerCase() || '').includes(search) ||
                (customer.phone_no || '').includes(search)
            );
        },
        filteredProfessionals() {
            if (!this.professionalSearch) return this.professionals;
             const search = this.professionalSearch.toLowerCase();
            return this.professionals.filter((professional) =>
                 (professional.prof_name?.toLowerCase() || '').includes(search) ||
                 (professional.serv_type?.toLowerCase() || '').includes(search) ||
                 (professional.prof_id?.toLowerCase() || '').includes(search) ||
                 (professional.status?.toLowerCase() || '').includes(search)
            );
        },
    },
    methods: {
        async fetchData() {
            this.loading = true;
            this.error = null;
            console.log("Fetching admin dashboard data...");
            try {
                // --- Use apiClient for BOTH requests ---
                // Make sure '/admin/customers' and '/admin/professionals' exist on backend
                // and are protected by @token_required
                const [customerRes, professionalRes] = await Promise.all([
                    apiClient.get("/admin/customers"),
                    apiClient.get("/admin/professionals")
                ]);
  
                // Check response structure from backend
                this.customers = customerRes.data?.customers || [];
                this.professionals = professionalRes.data?.professionals || [];
                console.log("Admin data received:", { customers: this.customers, professionals: this.professionals });
  
            } catch (error) {
                console.error("Error fetching admin data:", error);
                if (error.response && error.response.status !== 401) {
                    this.error = `Failed to load data (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
                } else if (!error.response) {
                     this.error = "Could not connect to the server.";
                } else {
                    // 401 handled by interceptor redirect
                    this.error = "Authentication failed. You may be redirected to login.";
                }
            } finally {
                this.loading = false;
            }
        },
  
        // --- Generic Action Handler ---
        async handleAdminAction(actionType, endpoint, successMessage, entityId) {
            this.isActionProcessing = entityId; // Set loading state for this specific entity
            this.actionError = null; // Clear previous action error
            console.log(`${actionType} action requested for ID: ${entityId}`);
  
            try {
                // --- Use apiClient for the POST request ---
                const response = await apiClient.post(endpoint);
  
                if (response.status === 200) {
                    alert(successMessage);
                    await this.fetchData(); // Refresh data after successful action
                } else {
                     console.warn(`${actionType} action failed with status:`, response.status, response.data);
                     this.actionError = response.data?.message || `Failed to ${actionType}.`;
                }
            } catch (error) {
                console.error(`Error during ${actionType} action:`, error);
                 if (error.response && error.response.status !== 401) {
                     this.actionError = `Error (${error.response.status}): ${error.response.data?.message || 'Server error during action.'}`;
                 } else if (!error.response) {
                      this.actionError = `Could not connect to the server for ${actionType}.`;
                 } else {
                     this.actionError = 'Authentication error during action.'; // 401 handled by interceptor
                 }
                  // Clear error after a few seconds
                 setTimeout(() => this.actionError = null, 4000);
            } finally {
                this.isActionProcessing = null; // Reset loading state
            }
        },
  
        // --- Specific action methods call the generic handler ---
        blockCustomer(customer_id) {
            this.handleAdminAction('block customer', `/block_customer/${customer_id}`, 'Customer blocked successfully!', customer_id);
        },
        unblockCustomer(customer_id) {
            this.handleAdminAction('unblock customer', `/unblock_customer/${customer_id}`, 'Customer unblocked successfully!', customer_id);
        },
        blockProfessional(prof_id) {
            this.handleAdminAction('block professional', `/block_professional/${prof_id}`, 'Professional blocked successfully!', prof_id);
        },
        unblockProfessional(prof_id) {
            this.handleAdminAction('unblock professional', `/unblock_professional/${prof_id}`, 'Professional unblocked successfully!', prof_id);
        },
        acceptProfessional(prof_id) {
             // Ensure the backend route '/accept_professional/<prof_id>' exists and is protected
            this.handleAdminAction('accept professional', `/accept_professional/${prof_id}`, 'Professional accepted successfully!', prof_id);
        },
  
        logout() {
            console.log("Logging out admin...");
            localStorage.removeItem('accessToken'); // Remove token
            this.$router.push('/admin/login'); // Redirect to admin login page
        },
  
        // --- Trigger Report (Keep commented or implement fully) ---
        /*
        async triggerReport() {
            this.reportStatus = "Generating report...";
            this.actionError = null;
            try {
                const response = await apiClient.post("/admin/generate-report"); // Ensure this backend route exists
                this.reportStatus = response.data?.message || "Report generation initiated.";
            } catch (error) {
                 console.error("Error generating report:", error);
                 if (error.response && error.response.status !== 401) {
                     this.actionError = `Report Error (${error.response.status}): ${error.response.data?.message || 'Server error.'}`;
                 } else if (!error.response) {
                      this.actionError = `Could not connect to the server for report.`;
                 } else {
                     this.actionError = 'Authentication error during report generation.';
                 }
                this.reportStatus = "Failed to generate report.";
            }
        },
        */
    },
    mounted() {
        // Optional: Check if token exists before fetching, redirect if not
        const token = localStorage.getItem('accessToken');
        if (!token) {
            console.warn("AdminDash: No token found, redirecting to admin login.");
            this.$router.push('/admin/login'); // Or appropriate login route
        } else {
            this.fetchData();
        }
    },
  };
  </script>
  
  <style scoped>
  /* --- Basic Styling (Adapt as needed) --- */
  .dashboard {
      font-family: sans-serif;
      color: #333;
  }
  .navbar {
    background-color: #1a1a1a;
    color: #00aaff;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #007bff;
  }
  .nav-link { color: #00aaff; text-decoration: none; margin-right: 15px;}
  .nav-link:hover { text-decoration: underline; }
  
  .logout-nav-btn {
      padding: 8px 15px; font-size: 0.9em; background-color: #dc3545; color: white;
      border: none; border-radius: 4px; cursor: pointer; transition: background-color 0.3s ease;
  }
  .logout-nav-btn:hover { background-color: #c82333; }
  
  .banner {
      background-color: #f0f0f0;
      padding: 20px;
      text-align: center;
      border-bottom: 1px solid #ccc;
  }
  .banner h1 { margin: 0; color: #333; }
  
  .container {
      padding: 20px;
      max-width: 1200px;
      margin: 20px auto;
  }
  
  .section-title {
      font-size: 1.4em;
      color: #007bff;
      margin-top: 30px;
      margin-bottom: 10px;
      border-bottom: 1px solid #eee;
      padding-bottom: 5px;
  }
  
  .search-bar {
      padding: 8px 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: 100%;
      max-width: 400px;
      box-sizing: border-box;
  }
  
  table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
      font-size: 0.9em;
  }
  
  th, td {
      border: 1px solid #ddd;
      padding: 8px 10px;
      text-align: left;
  }
  
  th {
      background-color: #f2f2f2;
      font-weight: bold;
  }
  
  tr:nth-child(even) {
      background-color: #f9f9f9;
  }
  
  .btn {
      padding: 5px 10px;
      margin-right: 5px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.9em;
      transition: opacity 0.3s ease;
  }
  .btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
  }
  
  .btn-block { background-color: #ffc107; color: #333; }
  .btn-unblock { background-color: #28a745; color: white; }
  .btn-accept { background-color: #17a2b8; color: white; }
  .btn-service { background-color: #007bff; color: white; margin-top: 10px; }
  
  .no-results {
      color: #777;
      font-style: italic;
      margin-top: 10px;
  }
  
  .loading-indicator, .error-text {
      text-align: center;
      padding: 20px;
      font-size: 1.1em;
  }
  .error-text { color: #dc3545; font-weight: bold; }
  .small-error { font-size: 0.9em; margin-top: 10px; text-align: center;}
  
  .service-management {
      margin-top: 20px;
      margin-bottom: 20px;
      border-top: 1px solid #eee;
      padding-top: 15px;
  }
  .service-management .btn {
      margin-right: 10px;
  }
  
  /* Report Styles (keep commented if feature is)
  .report-section { text-align: center; margin-top: 20px; }
  .report-status { margin-top: 10px; font-size: 16px; font-weight: bold; color: #17a2b8; } */
  </style>