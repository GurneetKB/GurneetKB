<template>
    <div class="container">
        <h1>Edit Existing Services</h1>
  
        <!-- Loading / Error for Fetching -->
        <div v-if="loading" class="loading-indicator">Loading services...</div>
        <div v-if="fetchError" class="error-text">Error loading services: {{ fetchError }}</div>
  
        <!-- Services Table -->
        <table v-if="!loading && !fetchError && services.length > 0" class="service-list">
            <thead>
                <tr>
                    <th>Service ID</th>
                    <th>Service Name</th>
                    <th>Price</th>
                    <th>Time Required (mins)</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="service in services" :key="service.service_id">
                    <td>{{ service.service_id }}</td>
                    <td>{{ service.service_name }}</td>
                    <td>{{ service.price }}</td>
                    <td>{{ service.time_required }}</td>
                    <td>{{ service.description }}</td>
                    <td>
                         <!-- Disable edit button if another service is being edited -->
                        <button class="btn btn-edit" @click="selectService(service)" :disabled="!!selectedService">
                            Edit
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
        <p v-if="!loading && !fetchError && services.length === 0" class="no-results">No services found to edit.</p>
  
  
        <!-- Edit Form (Visible only when a service is selected) -->
        <div v-if="selectedService" class="edit-form">
            <h2>Edit Service: {{ selectedService.service_id }}</h2>
             <div v-if="updateError" class="error-text small-error">Error updating: {{ updateError }}</div>
            <form @submit.prevent="updateService">
                <!-- Service ID is usually not editable, shown for info -->
                <!-- <input type="hidden" v-model="selectedService.service_id"> -->
  
                <div class="form-group">
                    <label for="edit_service_name">Service Name:</label>
                    <input type="text" id="edit_service_name" v-model="selectedService.service_name" required>
                </div>
  
                <div class="form-group">
                    <label for="edit_price">Price:</label>
                    <input type="number" id="edit_price" v-model.number="selectedService.price" required min="0">
                </div>
  
                <div class="form-group">
                    <label for="edit_time_required">Time Required (mins):</label>
                    <input type="number" id="edit_time_required" v-model.number="selectedService.time_required" min="0">
                </div>
  
                <div class="form-group">
                    <label for="edit_description">Description:</label>
                    <textarea id="edit_description" v-model="selectedService.description" rows="4" required></textarea>
                </div>
  
                <button type="submit" class="btn" :disabled="isUpdating">
                    {{ isUpdating ? 'Updating...' : 'Update Service' }}
                </button>
                <button type="button" class="btn cancel-btn" @click="cancelEdit" :disabled="isUpdating">
                    Cancel
                </button>
            </form>
        </div>
         <router-link v-if="!selectedService" to="/admin/dashboard" class="btn cancel-btn back-link">Back to Admin</router-link>
    </div>
  </template>
  
  <script>
  // --- IMPORT apiClient ---
  import apiClient from '../apiClient'; // Adjust path if needed
  
  export default {
    name: 'EditService', // Add name
    data() {
        return {
            services: [],
            selectedService: null,
            loading: true, // Loading state for fetching
            fetchError: null, // Error during fetching
            isUpdating: false, // Loading state for updating
            updateError: null, // Error during update
        };
    },
    methods: {
        async fetchServices() {
            this.loading = true;
            this.fetchError = null;
            console.log("Fetching services for editing...");
            try {
                // --- USE apiClient ---
                // Ensure backend '/service/get_services' exists, uses GET, protected
                const response = await apiClient.get('/service/get_services');
  
                // Check response structure (assuming {"services": [...]})
                if (response.data && Array.isArray(response.data.services)) {
                    this.services = response.data.services;
                    console.log("Services received:", this.services);
                } else {
                    console.error("Unexpected structure for services:", response.data);
                    this.fetchError = response.data?.message || "Invalid data format from server.";
                    this.services = [];
                }
            } catch (error) {
                console.error("Error fetching services:", error);
                 if (error.response && error.response.status !== 401) {
                     this.fetchError = `Error loading services (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
                 } else if (!error.response) {
                      this.fetchError = "Could not connect to the server.";
                 } else {
                     this.fetchError = "Authentication error."; // 401 handled by interceptor
                 }
                 this.services = [];
            } finally {
                this.loading = false;
            }
        },
        selectService(service) {
            // Create a deep copy to prevent accidental modification of the list item
            this.selectedService = JSON.parse(JSON.stringify(service));
            this.updateError = null; // Clear previous update errors
            // No need for editFormVisible flag, v-if="selectedService" handles it
        },
        async updateService() {
            if (!this.selectedService) return;
  
            this.isUpdating = true;
            this.updateError = null;
            console.log("Attempting to update service:", this.selectedService);
            try {
                 // --- USE apiClient ---
                 // Ensure backend '/service/edit' exists, uses POST, protected
                const response = await apiClient.post('/service/edit', this.selectedService);
  
                if (response.status === 200) {
                    console.log('Service updated successfully:', response.data);
                    alert(response.data?.message || 'Service updated successfully!');
                    await this.fetchServices(); // Refresh service list after update
                    this.cancelEdit(); // Hide edit form and clear selection
                } else {
                    console.warn('Update service failed with status:', response.status, response.data);
                    this.updateError = response.data?.message || `Failed to update (Status: ${response.status})`;
                }
  
            } catch (error) {
                console.error('Error updating service:', error);
                if (error.response && error.response.status !== 401) {
                     this.updateError = `Update Error (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
                 } else if (!error.response) {
                      this.updateError = 'Could not connect to the server to update.';
                 } else {
                     this.updateError = 'Authentication error.'; // 401 handled by interceptor
                 }
            } finally {
                this.isUpdating = false;
            }
        },
        cancelEdit() {
            this.selectedService = null; // Clear selected service
            this.updateError = null; // Clear update errors
        }
    },
    mounted() {
        this.fetchServices(); // Fetch services when the component loads
    }
  };
  </script>
  
  <style scoped>
  .container {
    max-width: 900px;
    margin: 20px auto;
    padding: 20px;
    background-color: #2a2a2a;
    border: 1px solid #007bff;
    border-radius: 8px;
    color: #e0e0e0;
  }
  h1, h2 {
    text-align: center;
    color: #00aaff;
    margin-bottom: 25px;
  }
  
  /* Table Styling */
  .service-list {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    margin-bottom: 30px; /* Space before edit form */
  }
  
  .service-list th,
  .service-list td {
    border: 1px solid #0056b3;
    padding: 10px;
    text-align: left;
    vertical-align: middle;
  }
  .service-list td:last-child, .service-list th:last-child { text-align: center; }
  
  .service-list th {
    background-color: #007bff;
    color: #fff;
  }
  
  .service-list td {
    background-color: #333;
    color: #e0e0e0;
    font-size: 0.9em;
  }
  .service-list tr:nth-child(even) td { background-color: #3a3a3a; }
  .service-list tr:hover td { background-color: #454545; }
  
  /* Form Styling */
  .edit-form {
    margin-top: 30px;
    padding: 25px;
    background: #333; /* Slightly lighter form background */
    border-radius: 5px;
    border: 1px solid #007bff;
  }
  .edit-form h2 { margin-bottom: 20px; }
  
  .form-group { margin-bottom: 15px; }
  label { display: block; margin-bottom: 5px; font-weight: bold; }
  input[type="text"], input[type="number"], textarea {
    width: 100%; padding: 10px; border: 1px solid #555; border-radius: 4px;
    background-color: #444; color: #fff; box-sizing: border-box;
  }
  input:focus, textarea:focus { border-color: #00aaff; outline: none; }
  textarea { resize: vertical; }
  
  .btn {
    display: inline-block;
    padding: 10px 20px;
    margin-right: 10px;
    margin-top: 10px; /* Space above buttons */
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.3s ease;
  }
  .btn:hover:not(:disabled) { background-color: #0056b3; }
  .btn:disabled { opacity: 0.6; cursor: not-allowed; }
  
  .btn-edit { background-color: #ffc107; color: #333; }
  .btn-edit:hover:not(:disabled) { background-color: #e0a800; }
  
  .cancel-btn { background-color: #6c757d; }
  .cancel-btn:hover:not(:disabled) { background-color: #5a6268; }
  
  .back-link { float: right; margin-top: -10px; } /* Position back link */
  
  .loading-indicator, .error-text, .no-results {
      text-align: center; padding: 15px; margin-top: 15px;
  }
  .loading-indicator { color: #00aaff; }
  .error-text { color: #ff4d4d; background-color: rgba(255, 77, 77, 0.1); border: 1px solid #ff4d4d; border-radius: 4px;}
  .small-error { font-size: 0.9em; margin-top: 10px; }
  .no-results { color: #aaa; font-style: italic;}
  
  </style>