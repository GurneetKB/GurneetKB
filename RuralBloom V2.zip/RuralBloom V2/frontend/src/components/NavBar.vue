--- START OF FILE frontend/src/components/Navbar.vue ---
<template>
  <nav class="navbar">
    <router-link to="/" class="nav-link">Home Page</router-link>
    <router-link to="/service-professional/login" class="nav-link">Work For Us?</router-link>
    <router-link to="/login" class="nav-link">Login</router-link>
  </nav>
</template>

<script>
export default {
  name: 'NavBar',
};
</script>

<style scoped>
.navbar {
  text-align: right;
  background-color: #000000;
  color: white;
  padding: 10px;
}

.nav-link {
  color: white;
  text-decoration: none;
  margin-right: 15px;
}

.nav-link:hover {
  text-decoration: underline;
}
</style>