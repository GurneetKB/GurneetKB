<template>
  <div>
    <!-- Navbar with Logout Button -->
    <div class="navbar">
      <router-link to="/">Home</router-link>
      <button @click="logout" class="logout-btn">Logout</button>
    </div>

    <!-- Banner -->
    <div class="banner">
      <h1 v-if="user">Welcome, {{ user.customer_name }}!</h1>
      <h1 v-else-if="isLoading">Loading...</h1>
      <h1 v-else-if="error">{{ error }}</h1>
      <p>Your one-stop dashboard for all your service needs</p>
    </div>

    <!-- Search Box -->
    <div class="search-box">
      <input v-model="searchQuery" type="text" placeholder="Search for services...">
    </div>

    <!-- Service List -->
    <div class="container">
      <div class="section-title">Explore Our Services</div>
      <div v-if="isLoading">Loading services...</div>
      <div v-else-if="error">{{ error }}</div>
      <div v-else-if="filteredServices.length > 0" class="grid">
        <div v-for="service in filteredServices" :key="service.service_id" class="card">
          <h5>{{ service.service_name }}</h5>
          <p>{{ service.description }}</p>
          <p>Price: ₹{{ service.price }}</p>
          <p>Time Required: {{ service.time_required }} mins</p>
          <button @click="confirmBooking(service.service_id)">Book</button>
        </div>
      </div>
      <div v-else-if="services.length > 0 && filteredServices.length === 0">
        <p>No services match your search.</p>
      </div>
      <div v-else>
        <p>No services available.</p>
      </div>
    </div>

    <!-- Confirmation Dialog -->
    <div v-if="selectedServiceId !== null" class="confirmation-overlay">
      <div class="confirmation-box">
        <h4>Are you sure you wish to book this service at your location?</h4>
        <button @click="bookService" class="confirm-btn" :disabled="isBooking">
          {{ isBooking ? 'Booking...' : 'OK' }}
        </button>
        <button @click="selectedServiceId = null" class="cancel-btn" :disabled="isBooking">
          Cancel
        </button>
        <p v-if="bookingError" class="error-text">{{ bookingError }}</p>
      </div>
    </div>

    <!-- User Activities -->
    <div class="container">
      <div class="section-title">Your Activities</div>
      <div class="grid">
        <div class="info-box">
          <h5>View Bookings This Week</h5>
          <router-link to="/customer/bookings">View</router-link>
        </div>
      </div>
    </div>

    <!-- Bookings List -->
    <div class="container">
      <div class="section-title">Your Bookings</div>
      <div v-if="bookingsLoading">Loading bookings...</div>
      <div v-else-if="bookingsError" class="error-text">{{ bookingsError }}</div>
      <div v-else-if="bookings.length > 0">
        <ul>
          <li v-for="booking in bookings" :key="booking.request_id">
            Service: {{ booking.service_name }}, Date: {{ booking.request_date }}, Status: {{ booking.status }}
          </li>
        </ul>
      </div>
      <div v-else>
        <p>No bookings found.</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://localhost:5000',
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.error('Unauthorized or Token Expired!');
      localStorage.removeItem('accessToken');
      alert('Your session has expired. Please log in again.');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default {
  name: 'CustDash',
  data() {
    return {
      user: null,
      services: [],
      searchQuery: '',
      selectedServiceId: null,
      isLoading: false,
      error: null,
      isBooking: false,
      bookingError: null,
      bookings: [],
      bookingsLoading: false,
      bookingsError: null,
    };
  },
  computed: {
    filteredServices() {
      return this.services.filter((service) =>
        service.service_name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    },
  },
  methods: {
    async fetchUserDataAndServices() {
      this.isLoading = true;
      this.error = null;
      try {
        const response = await apiClient.get('/customer/dashboard');
        if (response.data && response.data.user && response.data.services) {
          this.user = response.data.user;
          this.services = response.data.services;
        } else {
          console.error('Dashboard data missing:', response.data);
          this.error = 'Incomplete dashboard data from server.';
        }
      } catch (error) {
        console.error('Error fetching dashboard:', error);
        this.error = `Server error: ${error.message || 'Failed to load data.'}`;
      } finally {
        this.isLoading = false;
      }
    },

    confirmBooking(serviceId) {
      this.selectedServiceId = serviceId;
      this.bookingError = null;
    },

    async bookService() {
      if (!this.selectedServiceId || this.isBooking) return;

      this.isBooking = true;
      this.bookingError = null;

      try {
        const response = await apiClient.post(`/book_service/${this.selectedServiceId}`);
        if (response.status === 200) {
            alert('Service booked successfully!');
            this.selectedServiceId = null;
            // Refresh bookings after successful booking
            await this.fetchCustomerBookings();
        } else {
            this.bookingError = 'Booking failed.';
            console.error('Booking failed:', response);
        }

      } catch (error) {
        console.error('Error booking service:', error);
        this.bookingError = `Booking failed: ${error.message || 'Server error'}`;
      } finally {
        this.isBooking = false;
      }
    },

    async fetchCustomerBookings() {
      this.bookingsLoading = true;
      this.bookingsError = null;
      try {
        const response = await apiClient.get('/customer/bookings');
        if (response.status === 200 && response.data.bookings) {
          this.bookings = response.data.bookings;
        } else {
          this.bookingsError = 'Failed to fetch bookings.';
          console.error('Error fetching bookings:', response);
        }
      } catch (error) {
        this.bookingsError = `Error fetching bookings: ${error.message || 'Server error'}`;
        console.error('Error fetching bookings:', error);
      } finally {
        this.bookingsLoading = false;
      }
    },

    logout() {
      localStorage.removeItem('accessToken');
      this.$router.push('/login');
    },
  },
  mounted() {
    const token = localStorage.getItem('accessToken');
    if (!token) {
      this.$router.push('/login');
    } else {
      this.fetchUserDataAndServices();
      this.fetchCustomerBookings();
    }
  },
};
</script>

<style scoped>
/* Add styles for logout button and error text */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #1a1a1a;
  padding: 10px 20px;
}

.navbar a {
  color: #007bff;
  text-decoration: none;
  margin-left: 15px;
  transition: color 0.3s ease;
}
.navbar a:first-child {
  margin-left: 0;
}

.navbar a:hover {
  color: #0056b3;
}

.logout-btn {
  background-color: #dc3545;
  color: white;
  border: none;
  padding: 8px 15px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 0.9em;
  transition: background-color 0.3s ease;
  margin-left: 15px;
}

.logout-btn:hover {
  background-color: #c82333;
}

.error-text {
  color: #dc3545;
  margin-top: 10px;
  font-size: 0.9em;
}
body {
  background-color: #000;
  /* ... rest of your styles ... */
}
/* ... */
</style>