<template>
    <div class="form-container">
        <h2>Service Professional Registration</h2>
        <form @submit.prevent="handleRegistration">
            <label for="username">Username</label>
            <input type="text" id="username" v-model="serviceProfessional.username" required />

            <label for="password">Password</label>
            <input type="password" id="password" v-model="serviceProfessional.password" required />

            <label for="email">Email ID</label>
            <input type="email" id="email" v-model="serviceProfessional.email" required />
            
            <label for="name">Full Name</label>
            <input type="text" id="name" v-model="serviceProfessional.name" required />

            <label for="service_type">Service Type</label>
            <select id="service_type" v-model="serviceProfessional.service_type" required>
                <option value="" disabled>Select a Service Type</option>
                <option v-for="service in services" :key="service.service_id" :value="service.service_name">
                    {{ service.service_name }}
                </option>
            </select>

            <label for="experience">Years of Experience</label>
            <input type="number" id="experience" v-model="serviceProfessional.experience" required />

            <label for="phone">Phone No.</label>
            <input type="number" id="phone" v-model="serviceProfessional.phone" required />

            <button type="submit">Register</button>
        </form>
        <div v-if="registrationError" class="error-message">
            {{ registrationError }}
        </div>
        <div v-if="servicesError" class="error-message">
            {{ servicesError }}
        </div>
    </div>
</template>

<style scoped>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.form-container {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    border: 1px solid #ccc;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.form-container h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 20px;
}

.form-container label {
    display: block;
    margin-bottom: 5px;
    font-size: 14px;
}

.form-container input,
.form-container select {
    width: 100%;
    padding: 8px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
}

.form-container button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
}

.form-container button:hover {
    background-color: #0056b3;
}

.error-message {
    color: red;
    text-align: center;
    margin-top: 10px;
}
</style>

<script>
import axios from 'axios';

export default {
    name: "ServiceProfRegistration",
    data() {
        return {
            serviceProfessional: {
                username: "",
                password: "",
                email: "",
                name: "",
                service_type: "",
                experience: null,
                phone: null
            },
            services: [],
            registrationError: null,
            servicesError: null
        };
    },
    methods: {
        async fetchServices() {
            this.servicesError = null;
            try {
                const token = localStorage.getItem('accessToken');
                const response = await axios.get('http://localhost:5000/service/get_services', { //Correct API URL
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                if (response.status === 200) {
                    this.services = response.data.services;
                } else {
                    console.error("Error fetching services:", response.status, response.data);
                    this.servicesError = response.data.message || "Error fetching service types.";
                }

            } catch (error) {
                console.error("Error fetching services:", error);
                this.servicesError = "Error fetching service types. Please check console.";
            }
        },
        async handleRegistration() {
            this.registrationError = null;
            try {
                const token = localStorage.getItem('accessToken');

                const response = await axios.post('http://localhost:5000/service-professional/register', this.serviceProfessional, { //Correct API URL
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });

                if (response.status === 201) {
                    alert("Registration successful! Please wait for admin verification.");
                    this.$router.push("/login");
                }
                else {
                    console.error("Registration failed:", response.status, response.data);
                    this.registrationError = response.data.message || "Registration failed. Please try again.";
                }
            } catch (error) {
                console.error("Error during registration:", error);
                this.registrationError = "Error during registration. Please check console and try again.";
            }
        }
    },
    mounted() {
        this.fetchServices();
    }
};
</script>