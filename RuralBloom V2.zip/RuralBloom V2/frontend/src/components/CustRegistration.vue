<template>
  <div class="form-container">
    <div v-if="registrationSuccess" class="success-message">
      Registration successful! You can now log in.
      <router-link to="/login" class="login-link">Go to Login Page</router-link>
    </div>
    <div v-else>
      <h2>User Registration</h2>
      <form @submit.prevent="handleRegistration">
        <label for="username">Username</label>
        <input type="text" id="username" v-model="user.username" required />

        <label for="password">Password</label>
        <input type="password" id="password" v-model="user.password" required />

        <label for="email">Email ID</label>
        <input type="email" id="email" v-model="user.email" required />

        <label for="name">Full Name</label>
        <input type="text" id="name" v-model="user.name" required />

        <label for="phone">Phone Number</label>
        <input type="text" id="phone" v-model="user.phone" required />

        <label for="address">Address</label>
        <textarea id="address" v-model="user.address" rows="3"></textarea>

        <label for="city">City</label>
        <input type="text" id="city" v-model="user.city" required />

        <button type="submit">Register</button>
      </form>
    </div>
    <div v-if="registrationError" class="error-message">
      {{ registrationError }}
    </div>
  </div>
</template>

<style scoped>
/* Your styles remain the same */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f4f4f4;
}
.form-container {
  max-width: 500px;
  margin: 50px auto;
  padding: 20px;
  background-color: white;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}
.form-container h2 {
  text-align: center;
  margin-bottom: 20px;
}
.form-container label {
  display: block;
  margin-bottom: 5px;
}
.form-container input,
.form-container textarea {
  width: 100%;
  padding: 8px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 3px;
}
.form-container button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}
.form-container button:hover {
  background-color: #0056b3;
}
.success-message {
  text-align: center;
  color: green;
  margin-top: 20px;
}
.login-link {
  text-align: center;
  display: block;
  margin-top: 10px;
  color: #007bff;
  text-decoration: none;
}
.login-link:hover {
  text-decoration: underline;
}
.error-message {
  color: red;
  text-align: center;
  margin-top: 10px;
}
</style>

<script>
import axios from 'axios';

export default {
  name: "CustRegistration", // Corrected component name to CustRegistration (consistent with main.js)
  data() {
    return {
      user: {
        username: "",
        password: "",
        email: "",
        name: "",
        phone: "",
        address: "",
        city: ""
      },
      registrationSuccess: false,
      registrationError: null // To display registration errors
    };
  },
  methods: {
    async handleRegistration() {
      this.registrationError = null; // Reset error message
      try {
        const response = await axios.post(
          'http://localhost:5000/customer/register',
          this.user, // Data to send
        );

        if (response.status === 201) {
          console.log("Registration successful:", response.data);
          this.registrationSuccess = true;
        } else if (response.status === 409) { // CHECK FOR 409 CONFLICT STATUS
          this.registrationError = response.data.message || "Username already taken."; // Display "Username already exists" message
        } else {
          console.error("Registration failed:", response.status, response.data);
          this.registrationError = response.data.message || "Registration failed.";
        }
      } catch (error) {
        console.error("Error during registration:", error);
        this.registrationError = "Error during registration. Please try again.";
        if (error.response) {
          // The request was made and the server responded with a status code
          // that falls out of the range of 2xx
          console.log(error.response.data);
          console.log(error.response.status);
          console.log(error.response.headers);
        } else if (error.request) {
          // The request was made but no response was received
          // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
          // http.ClientRequest in node.js
          console.log(error.request);
        } else {
          // Something happened in setting up the request that triggered an Error
          console.log('Error', error.message);
        }
        console.log(error.config);
      }
    },
  }
};
</script>