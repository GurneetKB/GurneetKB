<template>
  <div class="login-container">
    <h2>Login</h2>

    <!-- Add loading state indicator -->
    <div v-if="isLoading" class="loading-message">Logging in...</div>

    <form @submit.prevent="login" v-else>
      <div class="input-group">
        <label for="username">Username</label>
        <input type="text" id="username" v-model="username" required />
      </div>

      <div class="input-group">
        <label for="email">Email ID</label>
        <input type="email" id="email" v-model="email" required />
      </div>

      <div class="input-group">
        <label for="password">Password</label>
        <input type="password" id="password" v-model="password" required />
      </div>

      <button type="submit" class="login-btn">Login</button>
    </form>

    <!-- Display Error Message -->
    <div v-if="loginError" class="error-message">
      {{ loginError }}
    </div>

    <div class="extra-buttons" v-if="!isLoading">
      <router-link to="/customer/register" class="register-btn">Customer Registration</router-link>
      <router-link to="/service-professional/register" class="register-btn">Service Professional Registration</router-link>
      <!-- Consider adding an Admin login link if needed, or handle it differently -->
    </div>
  </div>
</template>

<script>
import axios from 'axios'; // Can use global axios for login, or the apiClient instance

// --- Optional: Import the apiClient if you prefer consistency ---
// import apiClient from './apiClient'; // Adjust path if you saved apiClient elsewhere

export default {
  name: "LoginPage",
  data() {
    return {
      username: '',
      email: '',
      password: '',
      loginError: null,
      isLoading: false // Add loading state
    };
  },
  methods: {
    async login() {
      this.loginError = null;
      this.isLoading = true; // Set loading state

      try {
         // Use absolute URL to your backend login endpoint
        const response = await axios.post('http://localhost:5000/login', {
        // Or use apiClient: const response = await apiClient.post('/login', {
          username: this.username,
          email: this.email,
          password: this.password
        });

        // Check if login was successful and token received
        if (response.data && response.data.access_token) {
          console.log("Login successful:", response.data);

          // --- Store the JWT token in localStorage ---
          localStorage.setItem('accessToken', response.data.access_token);
          // --- END Store Token ---

          const userType = response.data.user_type; // Get user_type

          // --- Corrected Case Sensitivity ---
          if (userType === 'Customer') { // Compare against 'Customer' (Capitalized)
            this.$router.push('/customer/dashboard');
          } else if (userType === 'Professional') { // Compare against 'Professional' (Capitalized)
            // Make sure this route '/service-professional/dashboard' exists in your router config
            this.$router.push('/service-professional/dashboard');
          } else if (userType === 'Admin') { // Compare against 'Admin' (Capitalized)
            // Make sure this route '/admin/dashboard' exists in your router config
            this.$router.push('/admin/dashboard');
          } else {
            // This block should ideally not be reached if backend sends correct types
            console.error("Unknown user type received after login:", userType);
            // Remove potentially bad token if user type is unknown
            localStorage.removeItem('accessToken');
            this.loginError = "Login succeeded but user role is unrecognized. Cannot proceed.";
            // Don't redirect automatically, let user see the error.
            // alert("Login successful, but unknown user type. Redirecting to home.");
            // this.$router.push('/');
          }
        } else {
           // Handle cases where response might be 200 OK but token is missing
           console.error("Login response missing token:", response.data);
           this.loginError = "Login failed: Invalid response from server.";
        }

      } catch (error) {
          console.error("Error during login:", error);

          // --- Improved Error Handling ---
          if (error.response) {
              // Server responded with a status code outside the 2xx range
              console.error("Error response data:", error.response.data);
              console.error("Error response status:", error.response.status);
              // Use the error message from the backend if available
              this.loginError = error.response.data.message || `Login failed (Status: ${error.response.status})`;
          } else if (error.request) {
              // The request was made but no response was received
              console.error("Error request:", error.request);
              this.loginError = "No response from server. Please check network connection or if the server is running.";
          } else {
              // Something happened in setting up the request that triggered an Error
              console.error('Error message:', error.message);
              this.loginError = "An unexpected error occurred during login.";
          }
          // --- End Improved Error Handling ---
      } finally {
          this.isLoading = false; // Reset loading state regardless of outcome
      }
    }
  }
};
</script>

<style scoped>
.login-container {
  width: 90%; /* More responsive width */
  max-width: 350px; /* Max width */
  margin: 50px auto; /* Less top margin */
  padding: 25px;
  background: #2a2a2a; /* Slightly lighter dark */
  color: #e0e0e0; /* Lighter text */
  border: 1px solid #007bff; /* Adjusted border */
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 4px 15px rgba(0, 123, 255, 0.2); /* Add subtle shadow */
}

h2 {
  color: #00aaff; /* Lighter blue heading */
  margin-bottom: 25px;
}

.input-group {
  margin-bottom: 20px;
  text-align: left;
}

.input-group label {
  display: block;
  margin-bottom: 5px;
  font-size: 0.9em;
  color: #ccc; /* Lighter label color */
}

.input-group input {
  width: 100%;
  padding: 10px;
  border: 1px solid #555;
  border-radius: 4px;
  background-color: #333;
  color: #fff;
  box-sizing: border-box; /* Include padding in width */
}

 .input-group input:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
 }

.login-btn {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 12px 20px;
  border-radius: 5px;
  cursor: pointer;
  width: 100%; /* Full width button */
  font-size: 1.1em;
  margin-top: 10px; /* Add some space above */
  transition: background-color 0.3s ease;
}

.login-btn:hover {
  background-color: #0056b3;
}

.error-message {
  color: #ff4d4d; /* Brighter red */
  margin-top: 15px;
  font-size: 0.9em;
  font-weight: bold;
}

.loading-message {
   margin-top: 15px;
   color: #00aaff;
}

.extra-buttons {
  margin-top: 25px;
  display: flex;
  flex-direction: column; /* Stack buttons vertically */
  gap: 10px; /* Space between buttons */
}

.register-btn {
  color: #00aaff;
  text-decoration: none;
  font-size: 0.9em;
  padding: 8px; /* Add padding for better click area */
  border-radius: 4px;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.register-btn:hover {
  color: #fff;
  background-color: rgba(0, 123, 255, 0.2); /* Subtle background on hover */
  text-decoration: underline;
}
</style>