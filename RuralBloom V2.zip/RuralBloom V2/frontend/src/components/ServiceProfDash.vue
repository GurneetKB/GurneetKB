<template>
  <div>
    <!-- Navbar -->
    <div class="navbar">
      <span>Service Professional Dashboard</span>
       <!-- Add Logout Button here too -->
       <button @click="logout" class="logout-nav-btn">Logout</button>
    </div>

    <!-- Dashboard Container -->
    <div class="dashboard-container">
      <h1 v-if="!loading && prof">Welcome, {{ prof.prof_name }}</h1>
      <!-- Improved Loading/Error Display -->
      <div v-if="loading" class="loading-indicator">Loading Dashboard...</div>
      <div v-if="!loading && error" class="error-text">Error: {{ error }}</div>


      <!-- Service Requests Table -->
      <div v-if="!loading && !error">
        <h2>Pending Service Requests</h2>
        <table class="records-table" v-if="serviceRequests.length > 0">
          <thead>
            <tr>
              <th>Booking ID</th>
              <th>Customer ID</th>
              <th>Service Name</th>
              <!--<th>Order Date</th>--> <!-- Removed as not provided by backend -->
              <th>Address</th>
              <th>City</th>
              <!--<th>Rating</th>--> <!-- Rating not applicable until closed -->
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <!-- Add loading state for accept button -->
            <tr v-for="request in serviceRequests" :key="request.booking_id">
              <td>{{ request.booking_id }}</td>
              <td>{{ request.customer_id }}</td>
              <td>{{ request.service_name }}</td>
              <!--<td>{{ formatDate(request.order_date) }}</td>-->
              <td>{{ request.address }}</td>
              <td>{{ request.city }}</td>
              <!--<td>{{ request.rating }}</td>-->
              <td>
                <button
                  @click="acceptRequest(request.booking_id)"
                  class="accept-btn"
                  :disabled="isAccepting === request.booking_id"
                  >
                   {{ isAccepting === request.booking_id ? 'Accepting...' : 'Accept' }}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
        <div v-else class="no-requests">
          No pending service requests matching your service type.
        </div>
      </div>

       <!-- Display booking error if any -->
       <div v-if="acceptError" class="error-text small-error">
            {{ acceptError }}
       </div>

    </div>
  </div>
</template>

<script>
// --- IMPORT THE CONFIGURED API CLIENT ---
import apiClient from '../apiClient'; // Adjust path if apiClient.js is elsewhere

export default {
  name: 'ServiceProfDash', // Add component name
  data() {
    return {
      prof: null,
      serviceRequests: [],
      loading: true,
      error: null,
      isAccepting: null, // Track which request is being accepted
      acceptError: null, // Specific error for accept action
    };
  },
  mounted() {
    this.fetchDashboardData();
  },
  methods: {
    async fetchDashboardData() {
      this.loading = true;
      this.error = null;
      console.log("Fetching Service Professional Dashboard data...");
      try {
        // --- USE apiClient, REMOVE Manual Headers ---
        // The request interceptor in apiClient adds the token automatically
        const response = await apiClient.get('/service-professional/dashboard');

        // Check structure of response based on app.py
        if (response.data && response.data.professional && response.data.service_requests) {
          this.prof = response.data.professional;
          // Ensure service_requests is always an array
          this.serviceRequests = Array.isArray(response.data.service_requests) ? response.data.service_requests : [];
          console.log("Dashboard data received:", response.data);
        } else {
          console.error('Incomplete data received from server:', response.data);
          this.error = 'Received incomplete data from the server.';
        }
      } catch (error) {
        console.error('Error fetching service professional dashboard:', error);
         // Error handling simplified - 401s handled by interceptor redirect
        if (error.response && error.response.status !== 401) {
             this.error = `Error loading dashboard (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
        } else if (!error.response) { // Network error
            this.error = 'Could not connect to the server. Please check network or if the server is running.';
        }
        // No need to handle 401 explicitly here, interceptor does it.
      } finally {
        this.loading = false;
      }
    },

    async acceptRequest(bookingId) {
      this.isAccepting = bookingId; // Set loading state for this specific button
      this.acceptError = null; // Clear previous accept error
      console.log(`Attempting to accept request ID: ${bookingId}`);
      try {
        // --- USE apiClient ---
        const response = await apiClient.post(`/accept_service_request/${bookingId}`);

        if (response.status === 200) {
          // Remove the accepted request from the list locally for immediate UI update
          this.serviceRequests = this.serviceRequests.filter((req) => req.booking_id !== bookingId);
          alert('Service request accepted successfully!');
        } else {
            // This case might not be reached if axios throws for non-2xx status
            console.warn('Accept request responded with non-200 status:', response.status, response.data);
            this.acceptError = `Failed to accept: Server responded with status ${response.status}`;
             // Optional: Refresh data if unsure about state
             // await this.fetchDashboardData();
        }
      } catch (error) {
        console.error('Error accepting service request:', error);
        if (error.response && error.response.status !== 401) {
            this.acceptError = `Error accepting (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
        } else if (!error.response) {
            this.acceptError = 'Could not connect to the server to accept the request.';
        } else {
            // 401 handled by interceptor
             this.acceptError = 'Authentication error during accept action.';
        }
        // Don't refresh data automatically on error, let user see the message
      } finally {
        this.isAccepting = null; // Reset loading state for the button
      }
    },

    // --- Add Logout Method ---
    logout() {
        console.log("Logging out professional...");
        localStorage.removeItem('accessToken'); // Remove token
        this.$router.push('/login'); // Redirect to login
    },

    // formatDate method might not be needed if order_date isn't provided/used
    // formatDate(dateStr) {
    //   return dateStr ? new Date(dateStr).toISOString().split('T')[0] : 'N/A';
    // },
  },
};
</script>

<style scoped>
/* Existing styles */
body {
  font-family: Arial, sans-serif;
  background-color: #000;
  color: #00bfff;
  margin: 0;
  padding: 0;
}

.navbar {
  background-color: #1a1a1a; /* Darker navbar */
  color: #00aaff; /* Lighter blue */
  padding: 10px 20px;
  text-align: center;
  display: flex; /* Use flexbox */
  justify-content: space-between; /* Space out title and button */
  align-items: center; /* Center items vertically */
  border-bottom: 1px solid #007bff;
}

.navbar span {
    font-size: 1.2em;
    font-weight: bold;
}

.logout-nav-btn { /* Style for logout button in navbar */
    padding: 8px 15px;
    font-size: 0.9em;
    background-color: #dc3545; /* Red */
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}
.logout-nav-btn:hover {
    background-color: #c82333;
}


.dashboard-container {
  padding: 20px;
  margin: 20px auto;
  max-width: 1000px; /* Wider for table */
  background-color: #2a2a2a; /* Dark background */
  border: 1px solid #007bff;
  border-radius: 8px;
  box-shadow: 0 4px 15px rgba(0, 123, 255, 0.1);
}

.dashboard-container h1 {
  text-align: center;
  font-size: 1.8em; /* Slightly smaller H1 */
  color: #e0e0e0; /* Lighter text */
  margin-bottom: 20px;
}
.dashboard-container h2 {
    text-align: center;
    font-size: 1.4em;
    color: #00aaff; /* Match navbar */
    margin-top: 30px;
    margin-bottom: 15px;
    border-bottom: 1px solid #007bff;
    padding-bottom: 5px;
    display: inline-block; /* Fit border to text */
}


.records-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4); /* Add shadow to table */
}

.records-table th,
.records-table td {
  border: 1px solid #0056b3; /* Darker blue border */
  padding: 12px 10px; /* More padding */
  text-align: left; /* Left-align text in cells */
  vertical-align: middle; /* Center vertically */
}
.records-table td:last-child,
.records-table th:last-child {
    text-align: center; /* Center action button */
}


.records-table th {
  background-color: #007bff; /* Header background */
  color: #fff; /* Header text */
  font-size: 0.95em;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.records-table td {
  background-color: #333;
  color: #e0e0e0; /* Lighter cell text */
  font-size: 0.9em;
}

.records-table tr:nth-child(even) td {
    background-color: #3a3a3a; /* Slightly different for even rows */
}

.records-table tr:hover td {
  background-color: #454545; /* Row hover effect */
}

.accept-btn {
  padding: 6px 12px;
  background-color: #28a745; /* Green accept button */
  border: none;
  color: white;
  cursor: pointer;
  border-radius: 4px;
  font-size: 0.9em;
  transition: background-color 0.3s ease;
}

.accept-btn:hover:not(:disabled) {
  background-color: #218838;
}
.accept-btn:disabled {
    background-color: #5a5a5a;
    cursor: not-allowed;
}


.no-requests {
  text-align: center;
  color: #aaa;
  padding: 30px;
  font-style: italic;
}

.error-text {
  color: #ff4d4d; /* Brighter red */
  text-align: center;
  margin-top: 15px;
  font-weight: bold;
}
.small-error {
    font-size: 0.9em;
    margin-top: 10px;
}

.loading-indicator {
    text-align: center;
    padding: 30px;
    color: #00aaff;
    font-size: 1.2em;
}

/* Remove old logout button style if not needed */
.buttons-container { display: none; }
</style>