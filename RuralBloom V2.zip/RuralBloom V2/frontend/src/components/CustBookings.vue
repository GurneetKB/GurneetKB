<template>
    <!-- ... (template remains the same as the last corrected version) ... -->
      <div class="bookings-container">
      <h2>Your Bookings</h2>
      <div v-if="loading" class="loading-indicator">Loading bookings...</div>
      <div v-else-if="error" class="error-text">Error: {{ error }}</div>
      <table v-else-if="bookings.length > 0" class="bookings-table">
        <thead>
          <tr>
            <th>Booking ID</th>
            <th>Service Name</th>
            <!--<th>Price</th>-->
            <th>Status</th>
            <th>Rating</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="booking in bookings" :key="booking.booking_id">
            <td>{{ booking.booking_id }}</td>
            <td>{{ booking.service_name || 'N/A' }}</td>
            <!--<td>{{ booking.price || 'N/A' }}</td>-->
            <td>{{ booking.status }}</td>
            <td>
              <input
                v-if="booking.status === 'Accepted'"
                type="number"
                class="rating-input"
                v-model.number="booking.ratingInput"
                placeholder="1-5"
                min="1"
                max="5"
                step="1"
              />
              <span v-else-if="booking.status === 'Closed'">{{ booking.rating || 'N/A' }}</span>
              <span v-else>-</span>
            </td>
            <td>
              <button
                v-if="booking.status === 'Accepted'"
                @click="closeBooking(booking)"
                class="close-btn"
                :disabled="isClosing === booking.booking_id || !isValidRating(booking.ratingInput)"
              >
                 {{ isClosing === booking.booking_id ? 'Closing...' : 'Close & Rate' }}
              </button>
              <span v-else>{{ booking.status }}</span>
            </td>
          </tr>
        </tbody>
      </table>
      <p v-else class="no-bookings">No bookings available.</p>
      <div v-if="closeError" class="error-text small-error"> {{ closeError }} </div>
       <router-link to="/customer/dashboard" class="back-link">Back to Dashboard</router-link>
    </div>
  </template>
  
  <script>
  import apiClient from '../apiClient';
  
  export default {
    name: 'CustBookings',
    data() {
      return {
        bookings: [],
        loading: true,
        error: null,
        isClosing: null,
        closeError: null,
      };
    },
    mounted() {
      this.fetchBookings();
    },
    methods: {
      async fetchBookings() {
        this.loading = true;
        this.error = null;
        console.log("Fetching customer bookings...");
        try {
          const response = await apiClient.get('/customer/bookings');
  
          // --- CORRECTED CHECK HERE ---
          // Check for the 'bookings' key now, not 'user_bookings'
          if (response.data && Array.isArray(response.data.bookings)) {
              this.bookings = response.data.bookings.map(b => ({ // Use response.data.bookings
                  ...b,
                  ratingInput: b.status === 'Closed' ? b.rating : null
              }));
              console.log("Bookings received:", this.bookings);
          } else {
              console.error("Unexpected response structure for bookings:", response.data);
              this.error = response.data?.message || 'Failed to fetch bookings: Invalid data format from server.';
              this.bookings = [];
          }
        } catch (error) {
          console.error('Error fetching bookings:', error);
          if (error.response && error.response.status !== 401) {
              this.error = `Error fetching bookings (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
          } else if (!error.response) {
              this.error = 'Could not connect to the server to fetch bookings.';
          }
           this.bookings = [];
        } finally {
          this.loading = false;
        }
      },
  
      // --- closeBooking method remains the same ---
      async closeBooking(booking) {
        if (!this.isValidRating(booking.ratingInput)) {
            this.closeError = "Please enter a valid rating between 1 and 5.";
            setTimeout(() => this.closeError = null, 3000);
            return;
        }
        this.isClosing = booking.booking_id;
        this.closeError = null;
        console.log(`Attempting to close booking ID: ${booking.booking_id} with rating: ${booking.ratingInput}`);
        try {
          const response = await apiClient.post(
            `/close_booking/${booking.booking_id}`,
            { rating: booking.ratingInput }
          );
          if (response.status === 200) {
            booking.status = 'Closed';
            booking.rating = booking.ratingInput;
            alert('Booking closed successfully!');
          } else {
              this.closeError = response.data?.message || `Failed to close: Server responded with status ${response.status}`;
          }
        } catch (error) {
          console.error('Error closing booking:', error);
           if (error.response && error.response.status !== 401) {
               this.closeError = `Error closing (${error.response.status}): ${error.response.data?.message || 'Server error'}`;
           } else if (!error.response) {
               this.closeError = 'Could not connect to the server to close the booking.';
           } else {
               this.closeError = 'Authentication error during close action.';
           }
        } finally {
          this.isClosing = null;
        }
      },
      isValidRating(rating) {
          return typeof rating === 'number' && rating >= 1 && rating <= 5 && Number.isInteger(rating);
      }
    },
  };
  </script>
  
  <style scoped>
  /* --- Styles remain the same --- */
  .bookings-container {
    padding: 20px;
    margin: 20px auto;
    max-width: 800px; /* Adjust as needed */
    background-color: #2a2a2a;
    border: 1px solid #007bff;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 123, 255, 0.1);
    color: #e0e0e0;
  }
  
  h2 {
    text-align: center;
    color: #00aaff;
    margin-bottom: 25px;
  }
  
  .loading-indicator, .no-bookings {
    text-align: center;
    padding: 30px;
    color: #aaa;
    font-style: italic;
  }
  
  .bookings-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
  }
  
  .bookings-table th,
  .bookings-table td {
    border: 1px solid #0056b3;
    padding: 10px 12px;
    text-align: left;
    vertical-align: middle;
  }
  /* Center rating input/value and action button */
  .bookings-table td:nth-last-child(1), .bookings-table th:nth-last-child(1),
  .bookings-table td:nth-last-child(2), .bookings-table th:nth-last-child(2) {
      text-align: center;
  }
  
  
  .bookings-table th {
    background-color: #007bff;
    color: #fff;
    font-size: 0.9em;
    text-transform: uppercase;
  }
  
  .bookings-table td {
    background-color: #333;
    color: #e0e0e0;
    font-size: 0.9em;
  }
  .bookings-table tr:nth-child(even) td {
      background-color: #3a3a3a;
  }
  .bookings-table tr:hover td {
    background-color: #454545;
  }
  
  .rating-input {
      width: 60px; /* Smaller input */
      padding: 5px;
      background-color: #444;
      color: #fff;
      border: 1px solid #666;
      border-radius: 4px;
      text-align: center;
  }
  .rating-input:focus {
      outline: none;
      border-color: #00aaff;
  }
  
  
  .close-btn {
    padding: 6px 12px;
    background-color: #dc3545; /* Red for close */
    border: none;
    color: white;
    cursor: pointer;
    border-radius: 4px;
    font-size: 0.9em;
    transition: background-color 0.3s ease;
  }
  
  .close-btn:hover:not(:disabled) {
    background-color: #c82333;
  }
  .close-btn:disabled {
      background-color: #5a5a5a;
      cursor: not-allowed;
      opacity: 0.7;
  }
  
  .error-text {
    color: #ff4d4d;
    text-align: center;
    margin-top: 15px;
    font-weight: bold;
  }
  .small-error {
      font-size: 0.9em;
      margin-top: 10px;
  }
  
  .back-link {
      display: block;
      text-align: center;
      margin-top: 25px;
      color: #00aaff;
      text-decoration: none;
  }
  .back-link:hover {
      text-decoration: underline;
  }
  </style>