import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import PrimeVue from 'primevue/config';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.bundle.js';
import App from './App.vue';

// Importing components
import Home from './components/Home.vue';
import AdminDash from './components/AdminDash.vue';
import CustDash from './components/CustDash.vue';
import CustRegistration from './components/CustRegistration.vue';
import CustBookings from './components/CustBookings.vue';
import ServiceProfDash from './components/ServiceProfDash.vue';
import ServiceProfRegistration from './components/ServiceProfRegistration.vue';
import AddService from './components/AddService.vue';
import EditService from './components/EditService.vue';
import LoginPage from './components/LoginPage.vue';

// Define routes
const routes = [
  { path: '/', component: Home },
  { path: '/admin/dashboard', component: AdminDash },
  { path: '/customer/dashboard', component: CustDash },
  { path: '/customer/register', component: CustRegistration },
  { path: '/customer/bookings', component: CustBookings },
  { path: '/service-professional/dashboard', component: ServiceProfDash },
  { path: '/service-professional/register', component: ServiceProfRegistration },
  { path: '/service/add', component: AddService },
  { path: '/service/edit', component: EditService },
  { path: '/login', component: LoginPage },
];

// Create router instance
const router = createRouter({
  history: createWebHistory(),
  routes,
});

// Create and mount app
createApp(App).use(router).use(PrimeVue).mount('#app');
