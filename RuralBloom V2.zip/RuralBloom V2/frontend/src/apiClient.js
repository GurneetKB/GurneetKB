import axios from 'axios';

// --- Axios Instance with Interceptor ---
// Create an Axios instance so we can easily configure it
const apiClient = axios.create({
    baseURL: 'http://localhost:5000', // Your backend URL
    headers: {
        'Content-Type': 'application/json',
    }
});

// Add a request interceptor to include the token
apiClient.interceptors.request.use(config => {
    const token = localStorage.getItem('accessToken'); // Get token from localStorage
    if (token) {
        config.headers['Authorization'] = `Bearer ${token}`; // Add Authorization header
        console.log("Interceptor: Added Auth header"); // Optional: for debugging
    } else {
        console.log("Interceptor: No token found in localStorage"); // Optional: for debugging
    }
    return config;
}, error => {
    return Promise.reject(error);
});

// Add a response interceptor to handle 401 errors globally (optional but good)
apiClient.interceptors.response.use(response => {
   return response; // If response is ok, just return it
}, error => {
    if (error.response && error.response.status === 401) {
        console.error("Unauthorized (401) or Token Expired detected by interceptor!");
        // Token is invalid or expired, log the user out
        localStorage.removeItem('accessToken'); // Remove bad token

        // Redirect to login. Using window.location is simpler here if router instance isn't easily available.
        alert("Your session has expired or is invalid. Please log in again.");
        window.location.href = '/login'; // Force redirect to login page
    }
    // Important: Always reject the promise so downstream .catch() blocks in components can also run if needed
    return Promise.reject(error);
});
// --- End Axios Setup ---

// Export the configured instance to be used elsewhere
export default apiClient;